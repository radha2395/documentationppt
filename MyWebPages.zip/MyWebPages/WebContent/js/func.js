/**
 * 
 */

/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */



function validate(){
	
	if(document.getElementById("username").value==""){
		alert("Enter username!");
	}
	if(document.getElementById("pwd").value==""){
		alert("Enter password!");
	}
	document.getElementById('sbt')
	.addEventListener('click', function() {
		/* [… code saving data …] */
		alert('Thanks for submitting the form!');
	});
}
function showCompany()
{
	document.getElementById("company").hidden=false;
	
	}
function showProduct()
{
	document.getElementById("product").hidden=false;
	
	}
function validatesignup(){
	if(document.getElementById("name").value==""){
		alert("Enter name!");
	}
	if(document.getElementById("id").value==""){
		alert("Enter id!");
	}
	if(document.getElementById("username").value==""){
		alert("Enter username!");
	}
	if(document.getElementById("pwd").value==""){
		alert("Enter password!");
	}
	if(document.getElementById("pwd1").value==""){
		alert("Enter values!");
	}
}
