package com.inautix.onlinemedicalequipmentwebsite.dealer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;







import com.inautix.medicalequipmentwebsite.company.CompanyBean;
import com.inautix.onlinemedicalequipmentwebsite.medicalequipment.ConnectionManager;
import com.inautix.onlinemedicalequipmentwebsite.medicalequipment.MedicalEquipmentPOJO;

public class DealerDAO {

	public List<DealerBean> getAllDealers() {
		//return list of companies that deals with a particular product
		
		List<DealerBean> searchlist=null;
		DealerBean db=new DealerBean();
		
			Connection conn =ConnectionManager.getConnection();
			PreparedStatement stmt = null;
			/*PreparedStatement stmt1=null;
			PreparedStatement stmt2=null;
			int id;*/
			
			ResultSet resultset = null;
			
			
			String query = "SELECT * from T_XBBNHFW_Dealer";
			try {
				
				 stmt = conn.prepareStatement(query);
				 resultset = stmt.executeQuery();	
				while(resultset.next()) {
				 			searchlist=new ArrayList<DealerBean>();
				 			db.setD_id(resultset.getInt(1));
				 			db.setD_name(resultset.getString(2));
				 			db.setType(resultset.getInt(3));
				 			String str=resultset.getString(2);
				 			System.out.println(str);
				 			searchlist.add(db);
				 		}
				 	 
			}catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println("select catch");
				e.printStackTrace();
			}	
			finally{
				try {
					if(resultset != null)
					resultset.close();
					if(stmt != null)					
					stmt.close();				
					conn.commit();
					if(conn != null)
					conn.close();
				}			
				 catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
			return searchlist;
	
	}
	

	
	public DealerBean getDealer(String name) {
		//return list of companies that deals with a particular product
		
		
		DealerBean db=new DealerBean();
		
			Connection conn =ConnectionManager.getConnection();
			PreparedStatement stmt = null;
			/*PreparedStatement stmt1=null;
			PreparedStatement stmt2=null;
			int id;
			*/
			ResultSet resultset = null;
			
			
			String query = "SELECT * from T_XBBNHFW_Dealer where D_name=?";
			try {
				
				 stmt = conn.prepareStatement(query);
				 stmt.setString(1,name);
				 resultset = stmt.executeQuery();	
				
				
				 
				 		while(resultset.next()) {
				 			db.setD_id(resultset.getInt(1));
				 			db.setD_name(resultset.getString(2));
				 			db.setType(resultset.getInt(3));
				 							 			 		}
				 	 
			}catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println("select catch");
				e.printStackTrace();
			}	
			finally{
				try {
					if(resultset != null)
					resultset.close();
					if(stmt != null)					
					stmt.close();				
					conn.commit();
					if(conn != null)
					conn.close();
				}			
				 catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
			
	return db;
	}
	
	
	
	public List<MedicalEquipmentPOJO> getCompanyProducts(String cname)
	{// to return products that company deals with given an company name
		
	List<MedicalEquipmentPOJO> searchlist=null;
	MedicalEquipmentPOJO meq=new MedicalEquipmentPOJO();
		Connection conn =ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		PreparedStatement stmt1=null;
		PreparedStatement stmt2=null;
		int id;
		
		ResultSet resultset = null;
		ResultSet resultset1 = null;
		ResultSet resultset2 = null;	
		
		
		String query = "SELECT C_id  from T_XBBNHFW_Company where C_name=?";
		try {
			
			 stmt = conn.prepareStatement(query);
				stmt.setString(1,cname);
			 resultset = stmt.executeQuery();	
			
			
			 
			 	while(resultset.next()) {
				id=resultset.getInt("C_Id");
				String squery="SELECT EQ_id  from T_XBBNHFW_CompanySellsMeq where C_id=?";
			 
				stmt1 = conn.prepareStatement(squery);
				stmt1.setInt(1,id);
				resultset1 = stmt1.executeQuery();	
			 	}
	 
			 	while(resultset1.next()) {
			 		int id3=resultset1.getInt("EQ_Id");
			 		
			 		String squery="SELECT * from T_XBBNHFW_MedicalEquipment where EQ_id=?";	
			 		stmt2 = conn.prepareStatement(squery);
			 		stmt2.setInt(1,id3);
			 		resultset2 = stmt2.executeQuery();	
			 		while(resultset2.next()) {
			 			searchlist=new ArrayList<MedicalEquipmentPOJO>();
			 			meq.setEq_id(resultset2.getInt(1));
			 			meq.setEq_name(resultset2.getString(2));
			 			meq.setEq_price(resultset2.getFloat(3));
			 			meq.setEq_quantity(resultset2.getInt(4));
			 			String str=resultset2.getString("EQ_name");
			 			System.out.println(str);
			 			searchlist.add(meq);
			 		}
			 	} 
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("select catch");
			e.printStackTrace();
		}	
		finally{
			try {
				if(resultset != null)
				resultset.close();
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return searchlist;
	}
	
	public List<Integer> getEQidforDid(int id)
	{
		
		String query=null;
		List<Integer> idlist=new ArrayList<Integer>();
		Connection conn =ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		ResultSet rs=null;
		
			query="Select Eq_id from T_XBBNHFW_DealerdealsMeq where d_id=?";
		
	
		try {
			stmt = conn.prepareStatement(query);
			stmt.setInt(1,id);
										
			rs=stmt.executeQuery();
			while(rs.next()) {
			id=rs.getInt(1);
			idlist.add(id);
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		finally{
			try {
				
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
			return idlist;
	}
	
	public List<MedicalEquipmentPOJO> getDealerStock(int id)
	{
		List<MedicalEquipmentPOJO> searchlist=null;
		
		Connection conn =ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		
		
		ResultSet resultset = null;
		
		String query = "SELECT eq_id,eq_type,eq_price,eq_quantity  from T_XBBNHFW_DealerStock where C_id=?";
		try {
			
			 stmt = conn.prepareStatement(query);
				stmt.setInt(1,id);
			 resultset = stmt.executeQuery();	
			
			 searchlist=new ArrayList<MedicalEquipmentPOJO>();
			 
			 	while(resultset.next()) {
			 		MedicalEquipmentPOJO meq=new MedicalEquipmentPOJO();
			 			meq.setEq_id(resultset.getInt(1));
			 			meq.setEq_name(resultset.getString(2));
			 			meq.setEq_price(resultset.getFloat(3));
			 			meq.setEq_quantity(resultset.getInt(4));
			 			
			 			searchlist.add(meq);
			 		}
			 	
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("select catch");
			e.printStackTrace();
			return null;
		}	
		finally{
			try {
				if(resultset != null)
				resultset.close();
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return searchlist;
	}
	
	
	
	public List<CompanyBean> getCompany(String eqname) {
		//return list of companies that deals with a particular product
		
		List<CompanyBean> searchlist=new ArrayList<CompanyBean>();
	
			Connection conn =ConnectionManager.getConnection();
			PreparedStatement stmt = null;
			PreparedStatement stmt1=null;
			
			int id;
			
			ResultSet resultset = null;
			ResultSet resultset1 = null;
			
			
			String query = "SELECT c_id from T_XBBNHFW_DealerStock where EQ_type=?";
			try {
				
				 stmt = conn.prepareStatement(query);
					stmt.setString(1,eqname);
				 resultset = stmt.executeQuery();	
				
				
				 
				 	while(resultset.next()) {
					id=resultset.getInt(1);
					String squery="SELECT * from T_XBBNHFW_Company where C_id=?";
				 
					stmt1 = conn.prepareStatement(squery);
					stmt1.setInt(1,id);
					resultset1 = stmt1.executeQuery();	
				 	}
				 	
				 	while(resultset1.next()) {
				 		CompanyBean cb=new CompanyBean();
				 			cb.setC_id(resultset1.getInt(1));
				 			cb.setC_name(resultset1.getString(2));
				 			cb.setType(resultset1.getInt(3));
				 			searchlist.add(cb);
				 		}
				 	 
			}catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println("select catch");
				e.printStackTrace();
			}	
			finally{
				try {
					if(resultset != null)
					resultset.close();
					if(stmt != null)					
					stmt.close();				
					conn.commit();
					if(conn != null)
					conn.close();
				}			
				 catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
			return searchlist;
	
	}
	
	public List<String> getStockNames(int id) {
		//return list of companies that deals with a particular product
	
			Connection conn =ConnectionManager.getConnection();
			PreparedStatement stmt = null;
			
			PreparedStatement stmt2=null;
		
			
			ResultSet resultset = null;
			
			
		int a[]=new int[100];
		int i=0;
			List<String> searchlist=new ArrayList<String>();
			String query = "SELECT eq_id from T_XBBNHFW_DealerdealsMeq where d_id=?";
			
			try {
				stmt = conn.prepareStatement(query);
				stmt.setInt(1,id);
				resultset = stmt.executeQuery();	
				
				while(resultset.next())
				{
					int id1=resultset.getInt(1);
					a[i++]=id1;
				}
				ResultSet resultset1 = null;	
				for(int id2:a)
				{
					String dquery="select distinct eq_type from T_XBBNHFW_DealerStock where eq_id=?";
					stmt2 = conn.prepareStatement(dquery);
					stmt2.setInt(1,id2);
				 resultset1 = stmt.executeQuery();	
				}
				 	while(resultset1.next())
				 	{
				 		String str=resultset1.getString(1);
				 	/*	MedicalEquipmentPOJO meq= new MedicalEquipmentPOJO();
				 			meq.setEq_id(resultset1.getInt(1));
				 			meq.setEq_name(resultset1.getString(2));
				 			meq.setEq_price(resultset1.getFloat(3));
				 			meq.setEq_quantity(resultset1.getInt(4));*/
				 			searchlist.add(str);
				 		}
			
				
				
			}
			catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println("select catch");
				e.printStackTrace();
			}	
			finally{
				try {
					if(resultset != null)
					resultset.close();
					if(stmt != null)					
					stmt.close();				
					conn.commit();
					if(conn != null)
					conn.close();
				}			
				 catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
			return searchlist;
	
	}
	
	public int retDId(String name)
	{
		String query=null;
		int id=0;
		Connection conn =ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		ResultSet rs=null;
		
			query="Select D_id from T_XBBNHFW_Dealer where d_name=?";
		
	
		try {
			stmt = conn.prepareStatement(query);
			stmt.setString(1,name);
										
			rs=stmt.executeQuery();
			while(rs.next()) {
			id=rs.getInt(1);
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		finally{
			try {
				
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
			return id;
	}
	
	
	
	public List<Integer> getCompanyNames(int id) {
		//return list of companies that deals with a particular product
			List<Integer> searchlist=new ArrayList<Integer>();
		
			Connection conn =ConnectionManager.getConnection();
			PreparedStatement stmt = null;
		
			PreparedStatement stmt2=null;
			int id1;
			
			ResultSet resultset = null;
			ResultSet resultset1 = null;
	
			
			String query = "SELECT eq_id from T_XBBNHFW_DealerdealsMeq where d_id=?";
			try {
				
				 stmt = conn.prepareStatement(query);
					stmt.setInt(1,id);
				 resultset = stmt.executeQuery();	
				 
				while(resultset.next()) 
				{
					id1=resultset.getInt(1);
					System.out.println(id1);
					
				
					String dquery="select c_id from T_XBBNHFW_DealerStock where eq_id=?";
					stmt2 = conn.prepareStatement(dquery);
					stmt2.setInt(1,id1);
					resultset1 = stmt.executeQuery();	
						
				
					while(resultset1.next())
						{
						int cid=resultset1.getInt(1);	
						System.out.println("in dao"+cid);
				 			searchlist.add(cid);
				 		}
				
				}
			}catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println("select catch");
				e.printStackTrace();
			}	
			finally{
				try {
					if(resultset != null)
					resultset.close();
					if(stmt != null)					
					stmt.close();				
					conn.commit();
					if(conn != null)
					conn.close();
				}			
				 catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
			return searchlist;
	
	}
	
	
	
	public boolean insertStock(MedicalEquipmentPOJO meq,int id){
		Connection conn =ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		boolean res=false;
		String searchQuery;
		searchQuery="Insert into T_XBBNHFW_DealerStock values(?,?,?,?,?)";
		
			try {
			//System.out.println("Creating statement");
			 stmt = conn.prepareStatement(searchQuery);
			stmt.setInt(1, meq.getEq_id());		
			stmt.setString(2,meq.getEq_name());
			stmt.setFloat(3, meq.getEq_price());
			stmt.setInt(4,meq.getEq_quantity());
			stmt.setInt(5,id);
			stmt.execute();
			res=true;
			}

		catch(Exception e)
		{
			System.out.println("insert catch");
			e.printStackTrace();
		}
			finally{
				try {
					
					if(stmt != null)					
					stmt.close();				
					conn.commit();
					if(conn != null)
					conn.close();
				}			
				 catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
			return res;
	}

	public void insert(DealerBean db){
		Connection conn =ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		
		String searchQuery;
		searchQuery="Insert into T_XBBNHFW_Dealer values(?,?,?,?)";
		
			try {
			//System.out.println("Creating statement");
			 stmt = conn.prepareStatement(searchQuery);
			stmt.setInt(1, db.getD_id());		
			stmt.setString(2,db.getD_name());
			stmt.setInt(3,db.getType());
			stmt.setFloat(4, db.getD_rateofcomm());
			stmt.execute();
			}

		catch(Exception e)
		{
			System.out.println("insert catch");
			e.printStackTrace();
		}
			finally{
				try {
					
					if(stmt != null)					
					stmt.close();				
					conn.commit();
					if(conn != null)
					conn.close();
				}			
				 catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
	}

			public void delete(DealerBean db){
				Connection conn =ConnectionManager.getConnection();
				PreparedStatement stmt = null;
				String searchQuery="delete from T_XBBNHFW_Dealer where D_id=? ";
				try {
					stmt = conn.prepareStatement(searchQuery);
					stmt.setInt(1, db.getD_id());
												
					stmt.execute();
										
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				finally{
					try {
						
						if(stmt != null)					
						stmt.close();				
						conn.commit();
						if(conn != null)
						conn.close();
					}			
					 catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
				}
			}



			public int getCidforEquid(int eqid) {
				// TODO Auto-generated method stub
				String query=null;
				
				Connection conn =ConnectionManager.getConnection();
				PreparedStatement stmt = null;
				ResultSet rs=null;
				
					query="Select C_id from T_XBBNHFW_DealerStock where Eq_id=?";
				int id = 0;
			
				try {
					stmt = conn.prepareStatement(query);
					stmt.setInt(1,eqid);
												
					rs=stmt.executeQuery();
					while(rs.next()) {
				 id=rs.getInt(1);
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				finally{
					try {
						
						if(stmt != null)					
						stmt.close();				
						conn.commit();
						if(conn != null)
						conn.close();
					}			
					 catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
				}
					return id;
			}
			
			
}
