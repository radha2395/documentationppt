package com.inautix.onlinemedicalequipmentwebsite.medicalequipment;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.inautix.medicalequipmentwebsite.company.*;
import com.inautix.medicalequipmentwebsite.user.UserBean;
import com.inautix.onlinemedicalequipmentwebsite.dealer.*;

import java.util.Random;
public class MedicalEquipmentDAO
{
	
	public List<MedicalEquipmentPOJO> getSummaryForCompany(int id){
		
	//getting summary for company given an id
		Connection conn =ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		
		
		List<MedicalEquipmentPOJO> summaryList = null;
		ResultSet resultset = null;
		//searchQuery = "SELECT *  from T_XBBNHFW_MedicalEquipment where EQ_ID = ?  ";
				
		
		
		String query = "SELECT * from T_XBBNHFW_MedicalEquipment left outer JOIN T_XBBNHFW_CompanySellsMeq csm ON T_XBBNHFW_MedicalEquipment.eq_id=csm.eq_id where C_ID=? order by csm.eq_id";

			
		try {
			 stmt = conn.prepareStatement(query);
			 stmt.setInt(1, id);		
			 resultset = stmt.executeQuery();	
			
			 summaryList = new ArrayList<MedicalEquipmentPOJO>();
			 
			while(resultset.next()) {
				MedicalEquipmentPOJO e = new MedicalEquipmentPOJO();
				e.setEq_id(resultset.getInt(1));
				e.setEq_name(resultset.getString("EQ_TYPE"));
				e.setEq_price(resultset.getFloat("EQ_PRICE"));
				e.setEq_quantity(resultset.getInt("EQ_QUANTITY"));
				
				summaryList.add(e);
						
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("select catch");
			e.printStackTrace();
		}	
		finally{
			try {
				if(resultset != null)
				resultset.close();
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		return summaryList;
}

	
	
	public List<MedicalEquipmentPOJO> getSummaryForDealer(int id){
		
		//getting summary for dealer given an dealer id
			Connection conn =ConnectionManager.getConnection();
			PreparedStatement stmt = null;
			
			
			List<MedicalEquipmentPOJO> summaryList = null;
			ResultSet resultset = null;
			//searchQuery = "SELECT *  from T_XBBNHFW_MedicalEquipment where EQ_ID = ?  ";
					
			
			
			String query = "SELECT ds.EQ_ID,eq_type,eq_price,eq_quantity from T_XBBNHFW_DealerStock ds  left outer join T_XBBNHFW_DealerdealsMeq dsm on ds.eq_id=dsm.eq_id and D_ID=? order by ds.eq_id ";

						
			try {
				 stmt = conn.prepareStatement(query);
				 stmt.setInt(1, id);		
				 resultset = stmt.executeQuery();	
				
				 summaryList = new ArrayList<MedicalEquipmentPOJO>();
				 
				while(resultset.next()) {
					MedicalEquipmentPOJO e = new MedicalEquipmentPOJO();
					e.setEq_id(resultset.getInt(1));
					e.setEq_name(resultset.getString("EQ_TYPE"));
					e.setEq_price(resultset.getFloat("EQ_PRICE"));
					e.setEq_quantity(resultset.getInt("EQ_QUANTITY"));
					
					summaryList.add(e);
							
				}
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println("select catch");
				e.printStackTrace();
			}	
			finally{
				try {
					if(resultset != null)
					resultset.close();
					if(stmt != null)					
					stmt.close();				
					conn.commit();
					if(conn != null)
					conn.close();
				}			
				 catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
			
			return summaryList;
	}
	
	
	public List<MedicalEquipmentPOJO> getSummaryForUser(int id){
		
		//getting summary for company given an id
			Connection conn =ConnectionManager.getConnection();
			PreparedStatement stmt = null;
			
			List<MedicalEquipmentPOJO> summaryList = null;
			ResultSet resultset = null;
			
			
			
			
			String query = "SELECT us.EQ_ID,eq_type,eq_price,eq_quantity from T_XBBNHFW_UsererStock us left outer join T_XBBNHFW_UserBuysMeq ubm on us.eq_id=ubm.eq_id where U_ID=? order by us.eq_id ";

			
			try {
				 stmt = conn.prepareStatement(query);
				 stmt.setInt(1,id);		
				 resultset = stmt.executeQuery();	
				
				 summaryList = new ArrayList<MedicalEquipmentPOJO>();
				 
				while(resultset.next()) {
					MedicalEquipmentPOJO e = new MedicalEquipmentPOJO();
					e.setEq_id(resultset.getInt(1));
					e.setEq_name(resultset.getString("EQ_TYPE"));
					e.setEq_price(resultset.getFloat("EQ_PRICE"));
					e.setEq_quantity(resultset.getInt("EQ_QUANTITY"));
					
					summaryList.add(e);
							
				}
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println("select catch");
				e.printStackTrace();
			}	
			finally{
				try {
					if(resultset != null)
					resultset.close();
					if(stmt != null)					
					stmt.close();				
					conn.commit();
					if(conn != null)
					conn.close();
				}			
				 catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
			
			return summaryList;
			
				}
	
	
	public List<MedicalEquipmentPOJO> getCompanyProducts(String cname)
	{// to return products that company deals with given an company name
		
	List<MedicalEquipmentPOJO> searchlist=new ArrayList<MedicalEquipmentPOJO>();;
	MedicalEquipmentPOJO meq=new MedicalEquipmentPOJO();
		Connection conn =ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		PreparedStatement stmt1=null;
		PreparedStatement stmt2=null;
		int id;
		
		ResultSet resultset = null;
		ResultSet resultset1 = null;
		ResultSet resultset2 = null;	
		
		String query = "SELECT C_id  from T_XBBNHFW_Company where C_name=?";
		try {
			
			 stmt = conn.prepareStatement(query);
				stmt.setString(1,cname);
			 resultset = stmt.executeQuery();	
			
			
			 
			 	while(resultset.next()) {
				id=resultset.getInt("C_Id");
			 	
				String squery="SELECT EQ_id  from T_XBBNHFW_CompanySellsMeq where C_id=?";
			 
				stmt1 = conn.prepareStatement(squery);
				stmt1.setInt(1,id);
				resultset1 = stmt1.executeQuery();	
			 	}
			 	while(resultset1.next()) {
			 		int id1=resultset1.getInt(1);
			 		
			 		String squery="SELECT * from T_XBBNHFW_MedicalEquipment where EQ_ID=?";	
			 		stmt2 = conn.prepareStatement(squery);
			 		stmt2.setInt(1,id1);
			 		resultset2 = stmt2.executeQuery();	
			 		while(resultset2.next()) {
			 			meq=new MedicalEquipmentPOJO();
			 			meq.setEq_id(resultset2.getInt(1));
			 			meq.setEq_name(resultset2.getString(2));
			 			meq.setEq_price(resultset2.getFloat(3));
			 			meq.setEq_quantity(resultset2.getInt(4));
			 			searchlist.add(meq);
			 		}
			 	} 
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("select catch");
			e.printStackTrace();
		}	
		finally{
			try {
				if(resultset != null)
				resultset.close();
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return searchlist;
	}
	
	public List<MedicalEquipmentPOJO> getCompanyProductsForId(int id)
	{// to return products that company deals with given an company name
		
	List<MedicalEquipmentPOJO> searchlist=new ArrayList<MedicalEquipmentPOJO>();;
	MedicalEquipmentPOJO meq=new MedicalEquipmentPOJO();
		Connection conn =ConnectionManager.getConnection();
		
		PreparedStatement stmt2=null;
		
		
		ResultSet resultset2 = null;	
	
		try {
			
			
			 		
			 		String squery="SELECT * from T_XBBNHFW_MedicalEquipment where EQ_ID=?";	
			 		stmt2 = conn.prepareStatement(squery);
			 		stmt2.setInt(1,id);
			 		resultset2 = stmt2.executeQuery();	
			 		while(resultset2.next()) {
			 			meq=new MedicalEquipmentPOJO();
			 			meq.setEq_id(resultset2.getInt(1));
			 			meq.setEq_name(resultset2.getString(2));
			 			meq.setEq_price(resultset2.getFloat(3));
			 			meq.setEq_quantity(resultset2.getInt(4));
			 			searchlist.add(meq);
			 		}
			 	
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("select catch");
			e.printStackTrace();
		}	
		finally{
			try {
				if(resultset2 != null)
				resultset2.close();
				if(stmt2 != null)					
				stmt2.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return searchlist;
	}
	
	
public int retQty(String name)
{
	int qty = 0;
	Connection conn =ConnectionManager.getConnection();
	PreparedStatement stmt = null;
	ResultSet resultset = null;
	String query="Select eq_quantity from T_XBBNHFW_MedicalEquipment where eq_type=?";
			try {
				
				 stmt = conn.prepareStatement(query);
					stmt.setString(1,name);
				resultset = stmt.executeQuery();	
				while(resultset.next()) {
					
					qty=(resultset.getInt(1));
							
				}
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println("select catch");
				e.printStackTrace();
			}	
			finally{
				try {
					if(resultset != null)
					resultset.close();
					if(stmt != null)					
					stmt.close();				
					conn.commit();
					if(conn != null)
					conn.close();
				}			
				 catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
			
			return qty;	
	}


		
				

public boolean insert(MedicalEquipmentPOJO meq)
{//to insert into medicalequipment table
	Connection conn =ConnectionManager.getConnection();
	PreparedStatement stmt = null;
	boolean ch=false;
	String searchQuery;
	searchQuery="Insert into T_XBBNHFW_MedicalEquipment values(?,?,?,?)";
	
		try {
		//System.out.println("Creating statement");
		 stmt = conn.prepareStatement(searchQuery);
		stmt.setInt(1, meq.getEq_id());		
		stmt.setString(2,meq.getEq_name());
		stmt.setDouble(3,meq.getEq_price());
		stmt.setInt(4,meq.getEq_quantity() );
		ch=true;
		stmt.execute();
		System.out.println();
		System.out.println();
		System.out.println();
	
	}catch(Exception e)
	{
		System.out.println("insert catch");
		e.printStackTrace();
	}
		finally{
			try {
				
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return ch;
}

public boolean insertDealer(MedicalEquipmentPOJO meq,DealerBean db){
	//links dealer and equipment table
	
	boolean res=false;
	Random rand = new Random();

	int  n = rand.nextInt(50000) + 1;
	Connection conn =ConnectionManager.getConnection();
	PreparedStatement stmt = null;
	String searchQuery;
	searchQuery="Insert into T_XBBNHFW_DEALERDEALSMEQ values(?,?,?)";
	
		try {
		//System.out.println("Creating statement");
		 stmt = conn.prepareStatement(searchQuery);
		 stmt.setInt(1,n); 
		stmt.setInt(2,db.getD_id());
		stmt.setInt(3,meq.getEq_id());
		res=true;
		
		stmt.execute();
		System.out.println();
		System.out.println();
		System.out.println();
	
	}catch(Exception e)
	{
		System.out.println("insert catch");
		e.printStackTrace();
	}
		finally{
			try {
				
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return res;
}



public boolean insertCompany(MedicalEquipmentPOJO meq,CompanyBean cb){
	//links company and equipment table
	Connection conn =ConnectionManager.getConnection();
	PreparedStatement stmt = null;
	String searchQuery;
	Random rand = new Random();
boolean ch=false;
	int  n = rand.nextInt(50000) + 1;
	searchQuery="Insert into T_XBBNHFW_CompanySellsMeq values(?,?,?)";
	
		try {
		//System.out.println("Creating statement");
		 stmt = conn.prepareStatement(searchQuery);
		 stmt.setInt(1,n);
		stmt.setInt(2,cb.getC_id());
		stmt.setInt(3,meq.getEq_id());
		
		ch=true;
		stmt.execute();
		
	
	}catch(Exception e)
	{
		System.out.println("insert catch");
		e.printStackTrace();
	}
		finally{
			try {
				
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return ch;
}





public void insertUser(MedicalEquipmentPOJO medeq, UserBean ub) {
	// TODO Auto-generated method stub
	//links user and equipment table
		Connection conn =ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		String searchQuery;
		searchQuery="Insert into T_XBBNHFW_UserBuysMeq values(?,?,?)";
		Random rand = new Random();

		int  n = rand.nextInt(50000) + 1;
			try {
			//System.out.println("Creating statement");
			 stmt = conn.prepareStatement(searchQuery);
			stmt.setInt(1,n );		
			stmt.setInt(2,ub.getU_id());
			stmt.setInt(3,medeq.getEq_id());
			
			
			stmt.execute();
			System.out.println();
			System.out.println();
			System.out.println();
		
		}catch(Exception e)
		{
			System.out.println("insert catch");
			e.printStackTrace();
		}
			finally{
				try {
					
					if(stmt != null)					
					stmt.close();				
					conn.commit();
					if(conn != null)
					conn.close();
				}			
				 catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
	
}



public void delete(MedicalEquipmentPOJO meq)
		{//to delete from medicalEquipment
			Connection conn =ConnectionManager.getConnection();
			PreparedStatement stmt = null;
			String searchQuery="delete from T_XBBNHFW_MedicalEquipment where EQ_id=? ";
			try {
				stmt = conn.prepareStatement(searchQuery);
				stmt.setInt(1, meq.getEq_id());
											
				stmt.execute();
				System.out.println();
				System.out.println();
				System.out.println();
				System.out.println("Stock Details!\n");
				
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			finally{
				try {
					
					if(stmt != null)					
					stmt.close();				
					conn.commit();
					if(conn != null)
					conn.close();
				}			
				 catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
		}
		
public void updateDealer(int quantity,MedicalEquipmentPOJO meq, DealerBean dbean)
{//to update stock when dealer sells
				Connection conn =ConnectionManager.getConnection();
				PreparedStatement stmt = null;
				try {
					 
					 String searchQuery="update T_XBBNHFW_MedicalEquipment set EQ_QUANTITY=? where EQ_id=? ";
			
					stmt = conn.prepareStatement(searchQuery);
					stmt.setInt(1, meq.getEq_quantity()-quantity);
					stmt.setInt(2, meq.getEq_id());
					
					
					stmt.execute();
					System.out.println();
					System.out.println();
					System.out.println();
					
						System.out.println("Stock Details!\n");
					List<MedicalEquipmentPOJO> holdingList = getSummaryForDealer(dbean.getD_id());
					 Iterator<MedicalEquipmentPOJO> itr =  holdingList.iterator();
					while(itr.hasNext()){
						MedicalEquipmentPOJO medeqBean = itr.next();
						System.out.println(medeqBean.getEq_id()+ "\t"+ medeqBean.getEq_name()+ "\t"+ medeqBean.getEq_price()+ "\t"+ medeqBean.getEq_quantity());
					}
					
					
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				finally{
					try {
						
						if(stmt != null)					
						stmt.close();				
						conn.commit();
						if(conn != null)
						conn.close();
					}			
					 catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
				}
}



public void updateCompanyQuantity(int quantity,MedicalEquipmentPOJO medeq, CompanyBean cbean)
{//to update stock when company sells
				Connection conn =ConnectionManager.getConnection();
				PreparedStatement stmt = null;
				
				
				try {
				
		String 	searchQuery="update T_XBBNHFW_MedicalEquipment set EQ_QUANTITY=? where eq_id=?  ";
				
					stmt = conn.prepareStatement(searchQuery);
					stmt.setInt(1, medeq.getEq_quantity()-quantity);
					stmt.setInt(2, medeq.getEq_id());
					
					stmt.execute();
					System.out.println();
					System.out.println();
					System.out.println();
				
						System.out.println("Stock Details!\n");
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				finally{
					try {
						
						if(stmt != null)					
						stmt.close();				
						conn.commit();
						if(conn != null)
						conn.close();
					}			
					 catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
				}
			}

public boolean addCompanyQuantity(int quantity,MedicalEquipmentPOJO medeq, CompanyBean cbean)
{//to update stock when company sells
				Connection conn =ConnectionManager.getConnection();
				PreparedStatement stmt = null;
				//CompanyApp ca=new CompanyApp();
				boolean res=false;
				try {
				
		String 	searchQuery="update T_XBBNHFW_MedicalEquipment set EQ_QUANTITY=? where eq_type=?  ";
				
					stmt = conn.prepareStatement(searchQuery);
					stmt.setInt(1,quantity );
					stmt.setString(2, medeq.getEq_name());
					res=true;
					stmt.execute();
					System.out.println();
					
						
						
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				finally{
					try {
						
						if(stmt != null)					
						stmt.close();				
						conn.commit();
						if(conn != null)
						conn.close();
					}			
					 catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
				}
				return res;
			}




public boolean updateCompanyPrice(float price,MedicalEquipmentPOJO medeq, CompanyBean cbean)
{//to update stock when company sells
				Connection conn =ConnectionManager.getConnection();
				PreparedStatement stmt = null;
				
				boolean res=false;
				try {
				
		String 	searchQuery="update T_XBBNHFW_MedicalEquipment set EQ_Price=? where eq_type=?  ";
				
					stmt = conn.prepareStatement(searchQuery);
					stmt.setFloat(1, medeq.getEq_price());
					stmt.setString(2, medeq.getEq_name());
					res=true;
					stmt.execute();
					System.out.println();
					System.out.println();
					System.out.println();
				
						//System.out.println("Stock Details!\n");
						//ca.displayCompanyStock(cbean.getC_id());
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				finally{
					try {
						
						if(stmt != null)					
						stmt.close();				
						conn.commit();
						if(conn != null)
						conn.close();
					}			
					 catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
				}
				return res;
			}





			
}


	

