package com.inautix.onlinemedicalequipmentwebsite.medicalequipment;

//import java.util.Iterator;
//import java.util.List;
//import java.util.Scanner;

public class MedicalEquipmentApp {


}
