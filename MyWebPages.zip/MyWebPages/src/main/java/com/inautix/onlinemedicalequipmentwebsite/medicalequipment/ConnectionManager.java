package com.inautix.onlinemedicalequipmentwebsite.medicalequipment;



import java.sql.*;
//import java.util.*;


public class ConnectionManager {

   static Connection con;
   static String url;
         
   public static Connection getConnection()
   {
     
      try
      {
        
         
        // System.out.println("Initializing Driver");
     	Class.forName("oracle.jdbc.driver.OracleDriver");
         
                    	
            try {
            	//System.out.println("Creating Connection Statement");
				con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println("connection catch");
				e.printStackTrace();
			}
             								
         
         
         
      }

      catch(ClassNotFoundException e)
      {
         System.out.println(e);
      }

   return con;
}
}

