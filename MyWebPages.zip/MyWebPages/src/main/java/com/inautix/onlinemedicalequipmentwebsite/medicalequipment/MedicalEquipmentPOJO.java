package com.inautix.onlinemedicalequipmentwebsite.medicalequipment;

public class MedicalEquipmentPOJO {
	private Integer eq_id;
	private String eq_name;
		private float eq_price;
	private int eq_quantity;
	public MedicalEquipmentPOJO()
	{
		
	}
	public Integer getEq_id() {
		return eq_id;
	}
	public void setEq_id(Integer eq_id) {
		this.eq_id = eq_id;
	}

	public float getEq_price() {
		return eq_price;
	}
	public void setEq_price(float eq_price) {
		this.eq_price = eq_price;
	}
	public int getEq_quantity() {
		return eq_quantity;
	}
	public void setEq_quantity(int eq_quantity) {
		this.eq_quantity = eq_quantity;
	}
	public String getEq_name() {
		return eq_name;
	}
	public void setEq_name(String eq_name) {
		this.eq_name = eq_name;
	}


}
