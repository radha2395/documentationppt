package com.inautix.onlinemedicalequipmentwebsite.medicalequipment;

import java.util.List;

import com.inautix.medicalequipmentwebsite.company.CompanyBean;
import com.inautix.medicalequipmentwebsite.user.UserBean;
import com.inautix.onlinemedicalequipmentwebsite.dealer.DealerBean;

public interface MedicalEquipment {
	public List<MedicalEquipmentPOJO> getSummaryForCompany(int id);
	public List<MedicalEquipmentPOJO> getSummaryForDealer(int id);
	public List<MedicalEquipmentPOJO> getSummaryForUser(int id);
	public List<MedicalEquipmentPOJO> getCompanyProducts(String cname);
	public List<MedicalEquipmentPOJO> getCompanyProductsForId(int id);
	public int retQty(int id);
	public boolean insert(MedicalEquipmentPOJO meq);
	public boolean insertDealer(MedicalEquipmentPOJO meq,DealerBean db);
	public boolean insertCompany(MedicalEquipmentPOJO meq,CompanyBean cb);
	public void insertUser(MedicalEquipmentPOJO medeq, UserBean ub);
	public void delete(MedicalEquipmentPOJO meq);
	public void updateDealer(int quantity,MedicalEquipmentPOJO meq, DealerBean dbean);
	public void updateCompanyQuantity(int quantity,MedicalEquipmentPOJO medeq, CompanyBean cbean);
	public boolean addCompanyQuantity(int quantity,MedicalEquipmentPOJO medeq, CompanyBean cbean);
	public boolean updateCompanyPrice(float price,MedicalEquipmentPOJO medeq, CompanyBean cbean);
}
