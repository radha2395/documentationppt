package com.inautix.onlinemedicalequipmentwebsite.dealer;

import java.util.ArrayList;
import java.util.List;

import com.inautix.medicalequipmentwebsite.company.CompanyBean;

public class DealerBean {
private int d_id;
private String d_name;
private int type;
private float d_rateofcomm;

List<CompanyBean> cblist=new ArrayList<CompanyBean>();



public List<CompanyBean> getCblist() {
	return cblist;
}
public void setCblist(List<CompanyBean> cblist) {
	this.cblist = cblist;
}

public int getD_id() {
	return d_id;
}
public void setD_id(int d_id) {
	this.d_id = d_id;
}
public String getD_name() {
	return d_name;
}
public void setD_name(String d_name) {
	this.d_name = d_name;
}
public int getType() {
	return type;
}
public void setType(int type) {
	this.type = type;
}
public float getD_rateofcomm() {
	return d_rateofcomm;
}
public void setD_rateofcomm(float d_rateofcomm) {
	this.d_rateofcomm = d_rateofcomm;
}

}
