package com.inautix.onlinemedicalequipmentwebsite.dealer;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.inautix.medicalequipmentwebsite.company.*;
import com.inautix.onlinemedicalequipmentwebsite.medicalequipment.MedicalEquipmentDAO;
import com.inautix.onlinemedicalequipmentwebsite.medicalequipment.MedicalEquipmentPOJO;

public class DealerApp {
	
	private List<MedicalEquipmentPOJO> cprodlist;
	private List<MedicalEquipmentPOJO> cproductlist;

	public void dLoginActivity(int id)
	{
		int choice;
		Scanner s=new Scanner(System.in);
		do
		{
		System.out.println("What do you want to do?\n1.search stock \n2.search and buy stock \n3.view your stock\n4.logout");
		choice=s.nextInt();
		switch(choice)
		{
		case 1:
			search();
			break;
		case 2:
			buy();
			break;
		case 3:
			//displayDealerStock(id);
			break;
		case 4:
			System.out.println("Logging out!");
			return;
		default:
			System.out.println("Invalid choice!");
			break;
		}
		s.close();
	}while(choice!=4);
	}
	
	public void buy()
	{
		int ch;
		Scanner s=new Scanner(System.in);
		System.out.println("Enter parameter to search:\n1.company\n2.Product");
		ch=s.nextInt();
		switch(ch)
		{
		case 1:
			System.out.println("Enter a Companyname to search!");
	        String str = s.next();
			searchAndBuyByCompany(str);
			break;
		case 2:
			System.out.println("Enter a product name to search!");
	        String str1 = s.next();
				searchAndBuyByProducts(str1);
				break;
		default:
			System.out.println("Invalid choice!");
			break;
		}
		s.close();
	}
	
	public void sellMedEqByDealer(int qty,MedicalEquipmentPOJO medeq, DealerBean dbean)
	{
		MedicalEquipmentDAO meddao=new MedicalEquipmentDAO();
		meddao.updateDealer(qty,medeq,dbean);
		
		meddao.insertDealer(medeq,dbean);
		
	}

	public void search()
	{
		int ch;
		Scanner s=new Scanner(System.in);
		System.out.println("Enter parameter to search:\n1.company\n2.Product");
		ch=s.nextInt();
		switch(ch)
		{
		case 1:
			System.out.println("Enter a Companyname to search!");
	        String str = s.next();
			searchByCompany(str);
			break;
		case 2:
			 System.out.println("Enter a product name to search!");
		        String str1 = s.next();
				searchByProducts(str1);
				break;
		default:
			System.out.println("Invalid choice!");
			break;
		}
		s.close();
	}
	public List<MedicalEquipmentPOJO> searchByCompany(String str)
	{
		
		
		List<MedicalEquipmentPOJO> productlist=null;
        
        MedicalEquipmentDAO meddao=new  MedicalEquipmentDAO();
        productlist =meddao.getCompanyProducts(str);
        
        
return productlist;
	}
	
	
	public List<CompanyBean> searchByProducts(String str)
	{
		
		 CompanyDAO cdao=new  CompanyDAO();
		List<CompanyBean> companylist=null;
       
       companylist =cdao.getCompany(str);
       return companylist;
       
                
	}
	
	
	public void searchAndBuyByCompany(String cname)
	{
		Scanner s=new Scanner(System.in);
		String str1,str;
		List<MedicalEquipmentPOJO> productlist=null;
		DealerDAO ddao=new DealerDAO();
        MedicalEquipmentDAO meddao=new  MedicalEquipmentDAO();
        productlist =meddao.getCompanyProducts(cname);
        System.out.println("Choose a product name to buy!");
          str1=s.next();
          CompanyDAO cdao=new CompanyDAO();
         CompanyBean cb=cdao.getCompanyBean(cname);
        MedicalEquipmentPOJO meq,medeq;
        medeq=new MedicalEquipmentPOJO();
        Iterator<MedicalEquipmentPOJO> itr=productlist.iterator();
        while(itr.hasNext())
        {
        meq=itr.next();
        str=meq.getEq_name();
         if(str.equals(str1))
        	 medeq=meq;
           	 
        }
        System.out.println("Enter the quantity");
		 int qty=s.nextInt();
		 medeq.setEq_quantity(qty);
		 cprodlist = null;
		 cprodlist.add(medeq);
        cb.setMeqlist(cprodlist);
        int id=cdao.retId(cname);
        ddao.insertStock(medeq, id);
        buyMedEqByDealer(medeq, cb);
        s.close();

	}
	
	
	public void searchAndBuyByProducts(String pname)
	{
		Scanner s=new Scanner(System.in);
		String str1;
		DealerDAO ddao=new DealerDAO();
		cproductlist = null;
		  CompanyBean cb,cbean;
		  CompanyDAO cdao=new  CompanyDAO();
		List<CompanyBean> companylist=null;
         companylist =cdao.getCompany(pname);
        Iterator<CompanyBean> itr=companylist.iterator();
        System.out.println("Available Companies are:");
        while(itr.hasNext())
        {
        	cbean=itr.next();
        	System.out.println(cbean.getC_name());
        }
        
        System.out.println("Choose a Companyname to buy!");
          str1=s.next();
      
         cbean=new CompanyBean();    
        while(itr.hasNext())
        {
        cb=itr.next();
       String str2=cb.getC_name();
         if(str2.equals(str1))
        	 cbean=cb;
          }
        MedicalEquipmentPOJO meq,medeq;
        medeq=new MedicalEquipmentPOJO();
        List<MedicalEquipmentPOJO> productlist=cbean.getMeqlist();
        Iterator<MedicalEquipmentPOJO> itr1=productlist.iterator();
        while(itr1.hasNext())
        {
        meq=itr1.next();
        str1=meq.getEq_name();
         if(str1.equals(pname))
        	 medeq=meq;
         }
        System.out.println("Enter the quantity");
		 int qty=s.nextInt();
		 medeq.setEq_quantity(qty);
        cproductlist.add(medeq);
        cbean.setMeqlist(cproductlist);
        int id=cdao.retId(str1);
        ddao.insertStock(medeq, id);
       buyMedEqByDealer(medeq,cbean);
        s.close();
	}
	
	
	
	public MedicalEquipmentPOJO updatePrice(float rate,MedicalEquipmentPOJO medeq)
	{
		
		CompanyBean cb=new CompanyBean();
		List<MedicalEquipmentPOJO> holdingLists=new ArrayList<MedicalEquipmentPOJO>();
		
		 medeq.setEq_price(medeq.getEq_price()+rate*medeq.getEq_price());
		  holdingLists.add(medeq);
		 cb.setMeqlist(holdingLists);
		return medeq;
	}
	
		public boolean buyMedEqByDealer(MedicalEquipmentPOJO medeq, CompanyBean cbean)
	{
			DealerBean db=new DealerBean();
			MedicalEquipmentDAO mdao=new MedicalEquipmentDAO();
			List<CompanyBean> clist=new ArrayList<CompanyBean>();
			clist.add(cbean);
			db.setCblist(clist);
			int qty;
			
			DealerDAO ddao=new DealerDAO();
			
			
			
			MedicalEquipmentPOJO meq=updatePrice(db.getD_rateofcomm(),medeq);
			boolean res=ddao.insertStock(meq, cbean.getC_id());
			boolean res1=mdao.insertDealer(meq, db);
			CompanyApp capp=new CompanyApp();
			qty=medeq.getEq_quantity();
			capp.sellMedEqByCompany(qty,medeq,cbean);
			if(res==true && res1==true)
				return true;
			return false;
			
	}
}
