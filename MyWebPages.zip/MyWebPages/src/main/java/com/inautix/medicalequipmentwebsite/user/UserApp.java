package com.inautix.medicalequipmentwebsite.user;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;


//import com.inautix.medicalequipmentwebsite.company.CompanyApp;
import com.inautix.medicalequipmentwebsite.company.CompanyBean;
import com.inautix.medicalequipmentwebsite.company.CompanyDAO;
import com.inautix.onlinemedicalequipmentwebsite.dealer.DealerApp;
import com.inautix.onlinemedicalequipmentwebsite.dealer.DealerBean;
import com.inautix.onlinemedicalequipmentwebsite.dealer.DealerDAO;
import com.inautix.onlinemedicalequipmentwebsite.medicalequipment.MedicalEquipmentDAO;
import com.inautix.onlinemedicalequipmentwebsite.medicalequipment.MedicalEquipmentPOJO;

public class UserApp {

	public void uLoginActivity(int id) {
		// TODO Auto-generated method stub
		int choice;
		Scanner s=new Scanner(System.in);
		System.out.println("Available Dealers!");
		DealerDAO ddao=new DealerDAO();
		ddao.getAllDealers();
		System.out.println("Choose Dealer!");
		String dealer=s.next();
		DealerBean db=ddao.getDealer(dealer);
		do
		{
		System.out.println("What do you want to do?\n1.search stock \n2.search and buy stock \n3.view your stock\n4.logout");
		choice=s.nextInt();
		switch(choice)
		{
		case 1:
			search(db);
			break;
		case 2:
			buy(db);
			break;
		case 3:
			displayUserStock(id);
			break;
		case 4:
			System.out.println("Logging out!");
			return;
		default:
			System.out.println("Invalid choice!");
			break;
		}
		s.close();
	}while(choice!=4);
	}
	
	public void buy(DealerBean db)
	{
		int ch;
		Scanner s=new Scanner(System.in);
		System.out.println("Enter parameter to search:\n1.company\n2.Product");
		ch=s.nextInt();
		switch(ch)
		{
		case 1:
			 List<CompanyBean> clist=db.getCblist();
				Iterator<CompanyBean> itr1=clist.iterator();
				System.out.println("Available Companies!");
				while(itr1.hasNext())
				{
					CompanyBean cb=itr1.next();
					System.out.println(cb.getC_name());
				}
			System.out.println("Enter a Companyname to search!");
	        String str = s.next();
	       	searchAndBuyByCompany(str,db);
			break;
		case 2:
			System.out.println("Enter a product name to search!");
	        String str1 = s.next();
	        searchAndBuyByProducts(str1,db);
				break;
		default:
			System.out.println("Invalid choice!");
			break;
		}
		s.close();
	}
	public void search(DealerBean db)
	{
		int ch;
		Scanner s=new Scanner(System.in);
		System.out.println("Enter parameter to search:\n1.company\n2.Product");
		ch=s.nextInt();
		switch(ch)
		{
		case 1:
			//searchByCompany(db);
			break;
		case 2:
				//searchByProducts(db);
				break;
		default:
			System.out.println("Invalid choice!");
			break;
		}
		s.close();
	}
	public List<MedicalEquipmentPOJO> searchByCompany(String str)
	{
		CompanyDAO cdao=new CompanyDAO();
	
		List<MedicalEquipmentPOJO> productlist=null;
        
       DealerDAO ddao=new DealerDAO();
        int id=cdao.retId(str);
        productlist =ddao.getDealerStock(id);
        Iterator<MedicalEquipmentPOJO> itr=productlist.iterator();
		
		while(itr.hasNext())
		{
			MedicalEquipmentPOJO mb=(MedicalEquipmentPOJO)itr.next(); 
		System.out.println("From mtd"+mb.getEq_id());}
  return productlist;

	}
	
	
	public List<CompanyBean> searchByProducts(String str)
	{
		
		  DealerDAO ddao=new  DealerDAO();
		List<CompanyBean> companylist=null;
       
       companylist =ddao.getCompany(str);
      return companylist;
	}
	
	
	public void searchAndBuyByCompany(String str,DealerBean db)
	{
		Scanner s=new Scanner(System.in);
		String str1;
		DealerDAO ddao=new DealerDAO();
		CompanyDAO cdao=new CompanyDAO();
		List<MedicalEquipmentPOJO> productlist=null;
		        int id=cdao.retId(str);
	        productlist =ddao.getDealerStock(id);
	        MedicalEquipmentPOJO meq,medeq;
	        Iterator<MedicalEquipmentPOJO> itr1=productlist.iterator();
	        while(itr1.hasNext())
	        {
	        	meq=itr1.next();
	        System.out.println(meq.getEq_name());
	         }
          System.out.println("Choose a product name to buy!");
          str1=s.next();
         // CompanyDAO cdao=new CompanyDAO();
       //  CompanyBean cb=cdao.getCompanyBean(str);
     
        medeq=new MedicalEquipmentPOJO();
        Iterator<MedicalEquipmentPOJO> itr=productlist.iterator();
        while(itr.hasNext())
        {
        meq=itr.next();
        str=meq.getEq_name();
         if(str.equals(str1))
        	 medeq=meq;
             	 
        }
        buyMedEqByUser(medeq, db);
        s.close();

	}
	
	
	public void searchAndBuyByProducts(String str,DealerBean db)
	{
		Scanner s=new Scanner(System.in);
		String str1;
		  CompanyBean cb,cbean;
		
		List<CompanyBean> companylist=null;
		  DealerDAO ddao=new  DealerDAO();
	companylist =ddao.getCompany(str);
       Iterator<CompanyBean> itr=companylist.iterator();
       System.out.println("Available Companies are:");
       while(itr.hasNext())
       {
       	cbean=itr.next();
       	System.out.println(cbean.getC_name());
       }
        System.out.println("Choose a Companyname to buy!");
          str1=s.next();
      
        cbean=new CompanyBean();
        
        while(itr.hasNext())
        {
        cb=itr.next();
        str=cb.getC_name();
         if(str.equals(str1))
        	 cbean=cb;
          }
        MedicalEquipmentPOJO meq,medeq;
        medeq=new MedicalEquipmentPOJO();
        List<MedicalEquipmentPOJO> productlist=cbean.getMeqlist();
        Iterator<MedicalEquipmentPOJO> itr1=productlist.iterator();
        while(itr1.hasNext())
        {
        meq=itr1.next();
        str1=meq.getEq_name();
         if(str1.equals(str))
        	 medeq=meq;
             	 
        }
        
       buyMedEqByUser(medeq,db);
        s.close();
	}
	public void buyMedEqByUser(MedicalEquipmentPOJO medeq, DealerBean dbean)
	{
			UserBean ub=new UserBean();
			MedicalEquipmentDAO mdao=new MedicalEquipmentDAO();
			ub.setDb(dbean);
			int qty;
			Scanner s=new Scanner(System.in);
			System.out.println("Enter the quantity");
			qty=s.nextInt();
			DealerApp dapp=new DealerApp();
			dapp.sellMedEqByDealer(qty,medeq,dbean);
			mdao.insertUser(medeq, ub);
			displayUserStock(ub.getU_id());
			
			s.close();
	}


	
	public void displayUserStock(int id)
	{
		MedicalEquipmentDAO meddao=new MedicalEquipmentDAO();
		List<MedicalEquipmentPOJO> holdingList = meddao.getSummaryForUser(id);
		 Iterator<MedicalEquipmentPOJO> itr1 =  holdingList.iterator();
		 while(itr1.hasNext())
		 {
			 MedicalEquipmentPOJO meqBean = itr1.next();
			 System.out.println(meqBean.getEq_id()+ "\t"+ meqBean.getEq_name()+ "\t\t\t\t"+ meqBean.getEq_price()+ "\t\t"+ meqBean.getEq_quantity());
		 }
	}
		

}
