package com.inautix.medicalequipmentwebsite.user;

import java.util.ArrayList;
import java.util.List;

import com.inautix.onlinemedicalequipmentwebsite.dealer.DealerBean;
import com.inautix.onlinemedicalequipmentwebsite.medicalequipment.MedicalEquipmentPOJO;

public class UserBean {
private int u_id;
private String u_name;
private int type;
List<MedicalEquipmentPOJO> meqlist=new ArrayList<MedicalEquipmentPOJO>();
DealerBean db=new DealerBean();

public DealerBean getDb() {
	return db;
}
public void setDb(DealerBean db) {
	this.db = db;
}
public List<MedicalEquipmentPOJO> getMeqlist() {
return meqlist;
}
public void setMeqlist(List<MedicalEquipmentPOJO> meqlist) {
this.meqlist = meqlist;
}
public int getU_id() {
	return u_id;
}
public void setU_id(int u_id) {
	this.u_id = u_id;
}
public String getU_name() {
	return u_name;
}
public void setU_name(String u_name) {
	this.u_name = u_name;
}
public int getType() {
	return type;
}
public void setType(int type) {
	this.type = type;
}
}
