package com.inautix.medicalequipmentwebsite.company;

import java.util.List;

import com.inautix.onlinemedicalequipmentwebsite.medicalequipment.MedicalEquipmentPOJO;

public interface Company {
	public void insert(CompanyBean cb);
	public void delete(CompanyBean cb);
	public CompanyBean getCompanyBean(String str);
	public CompanyBean getCompanyBeanGivenID(int id) ;
	public List<CompanyBean> getAllCompany();
	public List<MedicalEquipmentPOJO> getAllStock();
	public List<CompanyBean> getCompany(String eqname);
}
