package com.inautix.medicalequipmentwebsite.login;

import com.inautix.medicalequipmentwebsite.company.CompanyBean;
import com.inautix.medicalequipmentwebsite.user.UserBean;
import com.inautix.onlinemedicalequipmentwebsite.dealer.DealerBean;

public class LoginDetailsBean {
	private String username;
	private String pwd;
	private int type;
	CompanyBean cb=new CompanyBean();
	UserBean ub=new UserBean();
	DealerBean db=new DealerBean();
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public CompanyBean getCb() {
		return cb;
	}
	public void setCb(CompanyBean cb) {
		this.cb = cb;
	}
	public UserBean getUb() {
		return ub;
	}
	public void setUb(UserBean ub) {
		this.ub = ub;
	}
	public DealerBean getDb() {
		return db;
	}
	public void setDb(DealerBean db) {
		this.db = db;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
		}
}
