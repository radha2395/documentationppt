package com.inautix.medicalequipmentwebsite.login;


import java.io.IOException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import com.inautix.medicalequipmentwebsite.company.*;
import com.inautix.medicalequipmentwebsite.user.*;
import com.inautix.onlinemedicalequipmentwebsite.dealer.*;
import com.inautix.onlinemedicalequipmentwebsite.medicalequipment.ConnectionManager;


public class LoginDetailsDAO {
	
	public int retId(LoginDetailsBean lb){
		String query=null;
		int id=0;
		Connection conn =ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		ResultSet rs=null;
		if(lb.getType()==1)
			query="Select C_id from T_XBBNHFW_Loginconcom where USERNAME=?";
		else if(lb.getType()==2)
			query="Select D_id from T_XBBNHFW_Logincondea where USERNAME=?";
		else if(lb.getType()==3)
			query="Select U_id from T_XBBNHFW_Loginconuse where USERNAME=?";
	
		try {
			stmt = conn.prepareStatement(query);
			stmt.setString(1,lb.getUsername());
										
			rs=stmt.executeQuery();
			while(rs.next()) {
			id=rs.getInt(1);
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		finally{
			try {
				
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
			return id;
	}
	
	public LoginDetailsBean retLbean(String uname)
	{
		LoginDetailsBean lbean=new LoginDetailsBean();
		Connection conn =ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		ResultSet rs=null;
		String searchQuery="select * from T_XBBNHFW_LoginDetails where USERNAME=? ";
		try {
			stmt = conn.prepareStatement(searchQuery);
			stmt.setString(1, uname);
										
			rs=stmt.executeQuery();
			if(rs!=null)
			{
			while(rs.next()) {
				String un=rs.getString(1);
				String pwd=rs.getString(2);
				int type=rs.getInt(3);
				lbean.setUsername(un);
				lbean.setPwd(pwd);
				lbean.setType(type);
			}
			}
			else
			{
				try
				{
					throw new Exception("Not Registered");
				}
				catch(Exception e)
				{
					e.getMessage();
				}
			}
			System.out.println();
			System.out.println();
			System.out.println();
			

			
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		finally{
			try {
				
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return lbean;
	}
	
	
	public boolean getInputsLogin(LoginDetailsBean ldb, String username, String pwd) throws NumberFormatException, IOException
	{
		
		//String username = null,pwd
		
		boolean res=false;
		while(res==false )
		{
		//System.out.println("Enter username as your Aadhar number");
		//username=br.readLine();
		ldb.setUsername(username);
		ldb=retLbean(username);
		//System.out.println("Enter password");
		//pwd=br.readLine();
		ldb.setPwd(pwd);
		
		res=checkLogin(ldb);
		//count ++;
		}
		/*if(count>3)
		{
			System.out.println("forgot password?Reset your password");
			System.out.println("enter your Id");
			id=Integer.parseInt(br.readLine());
			r=checkId(id,ldb.getType());
			System.out.println("enter new password!");
			pwd=br.readLine();
			System.out.println("confirm new password!");
			cpwd=br.readLine();
			if(cpwd.equals(pwd))
			ldb.setPwd(pwd);
			update(ldb);
		}*/
		
	
		return res;
		
	}
	
	
	
	public boolean checkId(int id, int type) {
		// TODO Auto-generated method stub
		switch(type)
		{
		case 1:
			CompanyBean cb=new CompanyBean();
			if(cb.getC_id()==id)
				return true;
			break;
		case 2:
			DealerBean db=new DealerBean();
			if(db.getD_id()==id)
				return true;
			break;
		case 3:
			UserBean ub=new UserBean();
			if(ub.getU_id()==id)
				return true;
			break;
		}
		return false;
	}


	
	public boolean checkSignUp(LoginDetailsBean ldbean)
	{
		Connection conn =ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		
		
		List<LoginDetailsBean> summaryList = null;
		ResultSet resultset = null;
				
		boolean res=true;
		String query = "SELECT *  from T_XBBNHFW_LoginDetails ";
		try 
		{
			 stmt = conn.prepareStatement(query);
			 resultset = stmt.executeQuery();	
			
			 summaryList = new ArrayList<LoginDetailsBean>();
			 
			while(resultset.next()) 
			{
				LoginDetailsBean ldb=new LoginDetailsBean();
				ldb.setUsername(resultset.getString("USERNAME"));
				ldb.setPwd(resultset.getString("PWD"));
				ldb.setType(resultset.getInt("TYPE"));
								
				summaryList.add(ldb);
				
				 Iterator<LoginDetailsBean> itr =  summaryList.iterator();
				while(itr.hasNext())
				{
					ldb=itr.next();
					if(ldb.getUsername()!=null)
						if(ldb.getUsername().equals(ldbean.getUsername()))
						{
							System.out.println("UserName Already Exists!\n\tTry another");
							res=false;
							break;
						}
						
				}
				
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("select catch");
			e.printStackTrace();
		}	
		finally{
			try {
				if(resultset != null)
				resultset.close();
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
	return res;	
}
	
	
	
		
	public boolean checkLogin(LoginDetailsBean ldbean) throws NumberFormatException, IOException
	{
		Connection conn =ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		
		
		List<LoginDetailsBean> summaryList = null;
		ResultSet resultset = null;
				
		boolean res=false,pwd=false;
		String query = "SELECT *  from T_XBBNHFW_LoginDetails ";
		try 
		{
			 stmt = conn.prepareStatement(query);
			 resultset = stmt.executeQuery();	
			
			 summaryList = new ArrayList<LoginDetailsBean>();
			 
			while(resultset.next()) 
			{
				LoginDetailsBean ldb=new LoginDetailsBean();
				ldb.setUsername(resultset.getString("USERNAME"));
				ldb.setPwd(resultset.getString("PWD"));
				ldb.setType(resultset.getInt("TYPE"));
								
				summaryList.add(ldb);
			}
				 Iterator<LoginDetailsBean> itr =  summaryList.iterator();
				while(itr.hasNext())
				{
					LoginDetailsBean ldb=itr.next();
					if(ldb.getUsername()!=null)
						if(ldb.getUsername().equals(ldbean.getUsername()))
						{
							pwd=checkPwd(ldbean);	
							if(pwd==true)
								res=true;
						}
						
				}
				
				
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("select catch");
			e.printStackTrace();
		}	
		finally{
			try {
				if(resultset != null)
				resultset.close();
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		return res;
}
	
	
	
	
	public boolean checkPwd(LoginDetailsBean ldbean) {
		// TODO Auto-generated method stub
		
		Connection conn =ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		
		
		List<LoginDetailsBean> summaryList = null;
		ResultSet resultset = null;
				
		boolean res=false;
		String query = "SELECT *  from T_XBBNHFW_LoginDetails ";
		try 
		{
			 stmt = conn.prepareStatement(query);
			 resultset = stmt.executeQuery();	
			
			 summaryList = new ArrayList<LoginDetailsBean>();
			 
			while(resultset.next()) 
			{
				LoginDetailsBean ldb=new LoginDetailsBean();
				ldb.setUsername(resultset.getString("USERNAME"));
				ldb.setPwd(resultset.getString("PWD"));
				ldb.setType(resultset.getInt("TYPE"));
								
				summaryList.add(ldb);
				
				 Iterator<LoginDetailsBean> itr =  summaryList.iterator();
				while(itr.hasNext())
				{
					ldb=itr.next();
					if(ldb.getPwd()!=null)
						if(ldb.getPwd().equals(ldbean.getPwd()))
						{
							res=true;	
						}
						
				}
				
				}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("select catch");
			e.printStackTrace();
		}	
		finally{
			try {
				if(resultset != null)
				resultset.close();
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		return res;
	}



	public boolean login(int ch,String username, String password) throws NumberFormatException, IOException
	{
			//int ch;
			
			boolean res=false;
			//BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			LoginDetailsBean ldb=new LoginDetailsBean();
			//System.out.println("\n\n\t\t\t\tMENU\n\t\t1.COMPANY\n\t\t2.DEALER\n\t\t3.USER\n\tenter choice");
				//ch=Integer.parseInt(br.readLine());
				
				switch(ch)
				{
				case 1:
					
					
					/*ldb=retLbean(username);*/
					ldb.setUsername(username);
					ldb.setPwd(password);
					ldb.setType(1);
					//id=retId(ldb);
					res=checkLogin(ldb);
					/*if(res==true)
						return 1;*/
					//res=getInputsLogin(ldb,username,password);
					//val=checkId(id,1);
				//if(val==true)
				//{
					//System.out.println("Succesfully logged in as COMPANY");
					//CompanyApp ca=new CompanyApp();
					//ca.cLoginActivity(id);	
					
				//}
				
				break;
				case 2:
					ldb.setType(2);
					ldb=retLbean(username);
					ldb.setPwd(password);
					//id=retId(ldb);
					res=checkLogin(ldb);
					//res=getInputsLogin(ldb,username,password);
				/*	if(res==true)
						return 2;*/
					/*id=getInputsLogin(ldb,username,password);
					val=checkId(id,2);
					if(val==true)
					{
						System.out.println("Succesfully logged in as DEALER");	
						DealerApp da=new DealerApp();
						da.dLoginActivity(id);		
						
					}
						
					*/break;
				case 3:
					ldb.setType(3);
					ldb=retLbean(username);
					ldb.setPwd(password);
					//id=retId(ldb);
					res=checkLogin(ldb);
					//res=getInputsLogin(ldb,username,password);
					/*if(res==true)
						return 3;*/
					/*id=getInputsLogin(ldb,username,password);
					val=checkId(id,3);
					if(val==true)
					{
						System.out.println("Succesfully logged in as USER");	
						//UserApp ua=new UserApp();
						//ua.uLoginActivity(id);	
					
					}*/
						
					break;
				}
	return res;
	}
	
	
	
	
	
	
	public boolean insert(LoginDetailsBean ldb){
		Connection conn =ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		boolean op=false;
		String searchQuery;
		searchQuery="Insert into T_XBBNHFW_LoginDetails values(?,?,?)";
		
			try {
			//System.out.println("Creating statement");
			 stmt = conn.prepareStatement(searchQuery);
			stmt.setString(1, ldb.getUsername());		
			stmt.setString(2,ldb.getPwd());
			stmt.setInt(3,ldb.getType());
			

			stmt.execute();
			op=true;
			
			}

		catch(Exception e)
		{
			System.out.println("insert catch");
			e.printStackTrace();
		}
			finally{
				try {
					
					if(stmt != null)					
					stmt.close();				
					conn.commit();
					if(conn != null)
					conn.close();
				}			
				 catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
			return op;
	}
	

	public void delete(LoginDetailsBean ldb){
		Connection conn =ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		String searchQuery="delete from T_XBBNHFW_LoginDetails where USERNAME=? ";
		try {
			stmt = conn.prepareStatement(searchQuery);
			stmt.setString(1, ldb.getUsername());
										
			stmt.execute();
			System.out.println();
			System.out.println();
			System.out.println();
			

			
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		finally{
			try {
				
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	
		public void update(LoginDetailsBean ldb) throws NumberFormatException, IOException
		{
			Connection conn =ConnectionManager.getConnection();
			PreparedStatement stmt = null;

			String searchQuery;
		searchQuery="update T_XBBNHFW_MedicalEquipment set  PWD=? where USERNAME=?";
			try {
				stmt = conn.prepareStatement(searchQuery);
				stmt.setString(1,ldb.getPwd());
				stmt.setString(2, ldb.getUsername());
				
				stmt.execute();
				System.out.println("Password Updated!Login to continue! :)");
				System.out.println();
				System.out.println();
				//login();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			finally{
				try {
					
					if(stmt != null)					
					stmt.close();				
					conn.commit();
					if(conn != null)
					conn.close();
				}			
				 catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
		}
	
	
	public boolean signUp(int ch,String uname,String pwd,String cpwd,CompanyBean cb, DealerBean db,UserBean ub) throws NumberFormatException, IOException
	{
		//int ch;
		
		boolean res=false,op=false;
		
		LoginDetailsBean ldb=new LoginDetailsBean();
		
			switch(ch)
			{
			case 1:
				CompanyDAO cdao=new CompanyDAO();
				cdao.insert(cb);
				ldb.setType(1);
				ldb.setCb(cb);
				ldb.setUsername(uname);
				res=checkSignUp(ldb);
				ldb.setPwd(pwd);
				op=insert(ldb);
				
				joinLoginCompany(cb,ldb);
				//ca.addCompanyStock(cb);
				break;
			case 2:
				
				DealerDAO ddao=new DealerDAO();
				
				ddao.insert(db);
				ldb.setType(2);
				ldb.setDb(db);
				ldb.setUsername(uname);
				res=checkSignUp(ldb);
				ldb.setPwd(pwd);
				op=insert(ldb);
				joinLoginDealer(db,ldb);
				
				
				
				//loginSignUp(2);
				break;
			case 3:
				
				UserDAO udao=new UserDAO(null);
				ub.setType(3);
				udao.insert(ub);
				ldb.setType(3);
				ldb.setUb(ub);
				ldb.setUsername(uname);
				res=checkSignUp(ldb);
				ldb.setPwd(pwd);
				op=insert(ldb);
				joinLoginUser(ub,ldb);
				//loginSignUp(3);
				break;
			
				
					
			}

			if(res==true && op==true)
				return true;
			return false;
	}


private void joinLoginUser(UserBean ub, LoginDetailsBean ldb) {
		// TODO Auto-generated method stub
	Connection conn =ConnectionManager.getConnection();
	PreparedStatement stmt = null;
	//boolean op=false;
	String searchQuery;
	Random rand = new Random();

	int  n = rand.nextInt(50000) + 1;
	searchQuery="Insert into T_XBBNHFW_Loginconuse values(?,?,?)";
	
		try {
		//System.out.println("Creating statement");
		 stmt = conn.prepareStatement(searchQuery);
		stmt.setInt(1, n);		
		stmt.setInt(2,ub.getU_id());
		stmt.setString(3,ldb.getUsername());
		

		stmt.execute();
		//op=true;
		
		}

	catch(Exception e)
	{
		System.out.println("insert catch");
		e.printStackTrace();
	}
		finally{
			try {
				
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}	
	}

private void joinLoginDealer(DealerBean db, LoginDetailsBean ldb) {
		// TODO Auto-generated method stub
	Connection conn =ConnectionManager.getConnection();
	PreparedStatement stmt = null;
	//boolean op=false;
	String searchQuery;
	Random rand = new Random();

	int  n = rand.nextInt(50000) + 1;
	searchQuery="Insert into T_XBBNHFW_Logincondea values(?,?,?)";
	
		try {
		//System.out.println("Creating statement");
		 stmt = conn.prepareStatement(searchQuery);
		stmt.setInt(1, n);		
		stmt.setInt(2,db.getD_id());
		stmt.setString(3,ldb.getUsername());
		

		stmt.execute();
		//op=true;
		
		}

	catch(Exception e)
	{
		System.out.println("insert catch");
		e.printStackTrace();
	}
		finally{
			try {
				
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
			
	}

public void joinLoginCompany(CompanyBean cb,LoginDetailsBean ldb) {
		// TODO Auto-generated method stub
	Connection conn =ConnectionManager.getConnection();
	PreparedStatement stmt = null;
	//boolean op=false;
	String searchQuery;
	Random rand = new Random();

	int  n = rand.nextInt(50000) + 1;
	searchQuery="Insert into T_XBBNHFW_Loginconcom values(?,?,?)";
	
		try {
		//System.out.println("Creating statement");
		 stmt = conn.prepareStatement(searchQuery);
		stmt.setInt(1, n);		
		stmt.setInt(2,cb.getC_id());
		stmt.setString(3,ldb.getUsername());
		

		stmt.execute();
		//op=true;
		
		}

	catch(Exception e)
	{
		System.out.println("insert catch");
		e.printStackTrace();
	}
		finally{
			try {
				
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		
	}



	/*private boolean loginSignUp(int ch,String username, String password) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
		
		boolean val=false;
		LoginDetailsBean ldb=new LoginDetailsBean();
		//int id=getInputsLogin(ldb);
		//val=checkId(id,i);
		ldb.setType(1);
		
		ldb=retLbean(username);
		ldb.setPwd(password);
		//id=retId(ldb);
		res=checkLogin(ldb);
		if(val==true)
		{
			switch(i)
			{
			case 1:
				System.out.println("Succesfully logged in as COMPANY");
				break;
			case 2:
				System.out.println("Succesfully logged in as DEALER");
				break;
			case 3:
				System.out.println("Succesfully logged in as USER");
				break;
			}
		}
			*/
	//}
	
}
