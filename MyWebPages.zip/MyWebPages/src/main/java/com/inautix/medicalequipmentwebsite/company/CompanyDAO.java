package com.inautix.medicalequipmentwebsite.company;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;



import com.inautix.onlinemedicalequipmentwebsite.medicalequipment.ConnectionManager;
import com.inautix.onlinemedicalequipmentwebsite.medicalequipment.MedicalEquipmentPOJO;



public class CompanyDAO implements Company{
	final static Logger logger = Logger.getLogger(CompanyDAO.class);
	public int retId(String str){
		logger.info("inside retId method");
		String query=null;
		int id=0;
		Connection conn =ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		ResultSet rs=null;
		
			query="Select C_id from T_XBBNHFW_Company where c_name=?";
		
	
		try {
			stmt = conn.prepareStatement(query);
			stmt.setString(1,str);
										
			rs=stmt.executeQuery();
			while(rs.next()) {
			id=rs.getInt(1);
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
		
			logger.error(e1);
		}
		finally{
			try {
				
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
			return id;
	}
	
public void insert(CompanyBean cb){
//insert Company Bean
	logger.info("inside insert method");
		Connection conn =ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		
		String searchQuery;
		searchQuery="Insert into T_XBBNHFW_Company values(?,?,?)";
		
			try {
			//System.out.println("Creating statement");
			 stmt = conn.prepareStatement(searchQuery);
			stmt.setInt(1, cb.getC_id());		
			stmt.setString(2,cb.getC_name());
			stmt.setInt(3,cb.getType());
			stmt.execute();
			}

		catch(Exception e)
		{
			System.out.println("insert catch");
			e.printStackTrace();
		}
			finally{
				try {
					
					if(stmt != null)					
					stmt.close();				
					conn.commit();
					if(conn != null)
					conn.close();
				}			
				 catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				
			}
			
	}


public void delete(CompanyBean cb){
//to delete a company bean
	logger.info("inside delete method");
	Connection conn =ConnectionManager.getConnection();
				PreparedStatement stmt = null;
				String searchQuery="delete from T_XBBNHFW_Company where C_id=? ";
				try {
					stmt = conn.prepareStatement(searchQuery);
					stmt.setInt(1, 6);
												
					stmt.execute();
										
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				finally{
					try {
						
						if(stmt != null)					
						stmt.close();				
						conn.commit();
						if(conn != null)
						conn.close();
					}			
					 catch (SQLException e) {
							// TODO Auto-generated catch block
							logger.error(e);
						}
				}
			}



public CompanyBean getCompanyBean(String str) {
// to retrive the entire bean given its name
	logger.info("inside getCompanyBean method");
				    Connection con =ConnectionManager.getConnection();
					PreparedStatement ps = null;
					CompanyBean cb=new CompanyBean();
					ResultSet rs = null;
			              String searchQuery="SELECT * FROM T_XBBNHFW_Company WHERE C_name=?";
			              
			              try
			              {
			             
			              ps=con.prepareStatement(searchQuery);
			              ps.setString(1, str);
			             
			              rs=ps.executeQuery();
			              while(rs.next())
			              {
			                     cb.setC_id(rs.getInt(1));
			                     cb.setC_name(rs.getString(2));
			                     cb.setType(rs.getInt(3));
			                    
			                     
			              }}
			              
			              catch(SQLException e)
			              {
			            		logger.error(e);
			              }
			              return cb;
			              
			      
			}

public CompanyBean getCompanyBeanGivenID(int id) {
	// to retrive the entire bean given its name
	logger.info("inside getCompanyGivenID method");
					    Connection con =ConnectionManager.getConnection();
						PreparedStatement ps = null;
						CompanyBean cb=new CompanyBean();
						ResultSet rs = null;
				              String searchQuery="SELECT * FROM T_XBBNHFW_Company WHERE C_id=?";
				              
				              try
				              {
				             
				              ps=con.prepareStatement(searchQuery);
				              ps.setInt(1, id);
				             
				              rs=ps.executeQuery();
				              while(rs.next())
				              {
				                     cb.setC_id(rs.getInt(1));
				                     cb.setC_name(rs.getString(2));
				                     cb.setType(rs.getInt(3));
				                    
				                     
				              }}
				              
				              catch(SQLException e)
				              {
				                     System.out.println(e);
				              }
				              finally{
									try {
										if(rs != null)
										rs.close();
										if(ps != null)					
										ps.close();				
										con.commit();
										if(con != null)
										con.close();
									}			
									 catch (SQLException e) {
											// TODO Auto-generated catch block
										 logger.error(e);
										}
				          
				              
				      
				}

				              return cb;
}

public List<CompanyBean> getAllCompany() {
	logger.info("inside getAllCompany method");
	List<CompanyBean> searchlist=new ArrayList<CompanyBean>();;
	
		Connection conn =ConnectionManager.getConnection();
		Statement stmt = null;
		CompanyBean cb;
		
		ResultSet resultset = null;
		
		
		String query = "select Distinct * from T_XBBNHFW_COMPANY";
		try {
			
			 stmt = conn.createStatement();
				 resultset = stmt.executeQuery(query);	
				 while(resultset.next()) {
			 			
			 			cb=new CompanyBean();
			 			cb.setC_id(resultset.getInt(1));
			 			cb.setC_name(resultset.getString(2));
			 			cb.setType(resultset.getInt(3));
			 			searchlist.add(cb);
				 }
		}catch (SQLException e) {
					// TODO Auto-generated catch block
					System.out.println("select catch");
					e.printStackTrace();
				}	
				finally{
					try {
						if(resultset != null)
						resultset.close();
						if(stmt != null)					
						stmt.close();				
						conn.commit();
						if(conn != null)
						conn.close();
					}			
					 catch (SQLException e) {
							// TODO Auto-generated catch block
						 logger.error(e);
						}
				}
				return searchlist;
			
			 
}









public List<MedicalEquipmentPOJO> getAllStock() {
	logger.info("inside getAllStock method");
	List<MedicalEquipmentPOJO> searchlist=new ArrayList<MedicalEquipmentPOJO>();;
	MedicalEquipmentPOJO meq=new MedicalEquipmentPOJO(); 
		Connection conn =ConnectionManager.getConnection();
		Statement stmt = null;
		
		
		ResultSet resultset = null;
		
		
		String query = "SELECT Distinct * from T_XBBNHFW_MedicalEquipment";
		try {
			
			 stmt = conn.createStatement();
			 resultset = stmt.executeQuery(query);	
				 while(resultset.next()) {
			 			meq=new MedicalEquipmentPOJO();
			 			meq.setEq_id(resultset.getInt(1));
			 			meq.setEq_name(resultset.getString(2));
			 			meq.setEq_price(resultset.getFloat(3));
			 			meq.setEq_quantity(resultset.getInt(4));
			 			searchlist.add(meq);
				 }
		}catch (SQLException e) {
					// TODO Auto-generated catch block
					System.out.println("select catch");
					e.printStackTrace();
				}	
				finally{
					try {
						if(resultset != null)
						resultset.close();
						if(stmt != null)					
						stmt.close();				
						conn.commit();
						if(conn != null)
						conn.close();
					}			
					 catch (SQLException e) {
							// TODO Auto-generated catch block
						 logger.error(e);
						}
				}
				return searchlist;
			
			 
}

public List<CompanyBean> getCompany(String eqname) {
				//return list of companies that deals with a particular product
			logger.info("inside getCompany method");
				List<CompanyBean> searchlist=new ArrayList<CompanyBean>();;
				CompanyBean cb=new CompanyBean();
					Connection conn =ConnectionManager.getConnection();
					PreparedStatement stmt = null;
					PreparedStatement stmt1=null;
					PreparedStatement stmt2=null;
					int id;
					
					ResultSet resultset = null;
					ResultSet resultset1 = null;
					ResultSet resultset2 = null;	
					
					
					String query = "SELECT  EQ_id  from T_XBBNHFW_MedicalEquipment where EQ_TYPE=?";
					try {
						
						 stmt = conn.prepareStatement(query);
							stmt.setString(1,eqname);
						 resultset = stmt.executeQuery();	
						
						
						 
						 	while(resultset.next()) {
							id=resultset.getInt(1);
						 	String squery="SELECT C_id  from T_XBBNHFW_CompanySellsMeq where EQ_id=?";
						 	
							stmt1 = conn.prepareStatement(squery);
							stmt1.setInt(1,id);
							resultset1 = stmt1.executeQuery();	
						 	
				 
						 	while(resultset1.next()) {
						 		int id1=resultset1.getInt(1);
						 	
						 		 squery="SELECT * from T_XBBNHFW_Company where C_id=?";	
						 		stmt2 = conn.prepareStatement(squery);
						 		stmt2.setInt(1,id1);
						 		resultset2 = stmt2.executeQuery();	
						 	}
						 		while(resultset2.next()) {
						 			cb=new CompanyBean();
						 			cb.setC_id(resultset2.getInt(1));
						 			String str=resultset2.getString(2);
						 			cb.setC_name(str);
						 			cb.setType(resultset2.getInt(3));
						 			
						 			System.out.println(str);
						 			searchlist.add(cb);
						 		}
						 
						 	} 
					}catch (SQLException e) {
						// TODO Auto-generated catch block
						System.out.println("select catch");
						logger.error(e);
					}	
					finally{
						try {
							if(resultset != null)
							resultset.close();
							if(stmt != null)					
							stmt.close();				
							conn.commit();
							if(conn != null)
							conn.close();
						}			
						 catch (SQLException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
					}
					return searchlist;
			
			}
			
			
	}


		



