package com.inautix.medicalequipmentwebsite.user;

import java.util.List;

import com.inautix.onlinemedicalequipmentwebsite.medicalequipment.MedicalEquipmentPOJO;

public interface User {
	public List<MedicalEquipmentPOJO> getDealerStock(int id);
	public void insert(UserBean ub);
	public void delete(UserBean ub);
}
