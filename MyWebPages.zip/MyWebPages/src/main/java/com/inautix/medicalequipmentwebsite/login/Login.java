package com.inautix.medicalequipmentwebsite.login;

import com.inautix.medicalequipmentwebsite.company.CompanyBean;
import com.inautix.medicalequipmentwebsite.user.UserBean;
import com.inautix.onlinemedicalequipmentwebsite.dealer.DealerBean;

public interface Login {
	public int retId(LoginDetailsBean lb);
	public LoginDetailsBean retLbean(String uname);
	public boolean getInputsLogin(LoginDetailsBean ldb, String username, String pwd) ;
	public boolean checkId(int id, int type);
	public boolean checkSignUp(LoginDetailsBean ldbean);
	public boolean checkLogin(LoginDetailsBean ldbean);
	public boolean checkPwd(LoginDetailsBean ldbean);
	public boolean login(int ch,String username, String password);
	public boolean insert(LoginDetailsBean ldb);
	public void delete(LoginDetailsBean ldb);
	public void update(LoginDetailsBean ldb);
	public boolean signUp(int ch,String uname,String pwd,String cpwd,CompanyBean cb, DealerBean db,UserBean ub) ;
	void joinLoginUser(UserBean ub, LoginDetailsBean ldb);
	 void joinLoginDealer(DealerBean db, LoginDetailsBean ldb);
	 void joinLoginCompany(CompanyBean cb,LoginDetailsBean ldb);
}
