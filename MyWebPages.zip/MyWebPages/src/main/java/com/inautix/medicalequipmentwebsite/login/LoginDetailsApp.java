package com.inautix.medicalequipmentwebsite.login;

//import java.io.IOException;
//import java.util.*;

public class LoginDetailsApp {
	/*public static void main(String args[]) throws NumberFormatException, IOException 
	{
		int ch;
		//BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		Scanner s=new Scanner(System.in);
		LoginDetailsDAO ldd=new LoginDetailsDAO();
		//do{
		System.out.println("\n\n\t\t\t\tMENU\n\t\t1.REGISTER\n\t\t2.LOGIN\n\t\t3.EXIT\n\tenter choice");
			ch=s.nextInt();
			
			switch(ch)
			{
			case 1:
				ldd.signUp();
				break;
			case 2:
				ldd.login();
				break;
			case 3:
				System.out.println("Exitting!!!");
				break;
			default:
				System.out.println("INVALID INPUT!");
				break;
			}
			
	//}while(ch!=3);
		s.close();
	}*/
}
