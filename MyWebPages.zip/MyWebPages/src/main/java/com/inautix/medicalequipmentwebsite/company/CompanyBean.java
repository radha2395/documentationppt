package com.inautix.medicalequipmentwebsite.company;

import java.util.ArrayList;
import java.util.List;

import com.inautix.onlinemedicalequipmentwebsite.medicalequipment.MedicalEquipmentPOJO;

public class CompanyBean {
	private String c_name;
	private int c_id;
	private int type;
	
 List<MedicalEquipmentPOJO> meqlist=new ArrayList<MedicalEquipmentPOJO>();
	
	
	public List<MedicalEquipmentPOJO> getMeqlist() {
	return meqlist;
}

	public String getC_name() {
		return c_name;
	}
	public void setC_name(String c_name) {
		this.c_name = c_name;
	}
	public int getC_id() {
		return c_id;
	}
	public void setC_id(int c_id) {
		this.c_id = c_id;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public void setMeqlist(List<MedicalEquipmentPOJO> meqlist) {
		// TODO Auto-generated method stub
		this.meqlist = meqlist;
	}
	

}
