package com.inautix.medicalequipmentwebsite.user;

import java.sql.Connection;
import java.sql.PreparedStatement;

import java.sql.SQLException;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.inautix.onlinemedicalequipmentwebsite.medicalequipment.ConnectionManager;
import com.inautix.onlinemedicalequipmentwebsite.medicalequipment.MedicalEquipmentPOJO;
import com.nxn.tra.api.rowmapper.TestRowMapper;
@Component
public class UserDAO extends JdbcDaoSupport {
	
	@Autowired
	public UserDAO(DataSource datasource)
	{
		// TODO Auto-generated constructor stub
				setDataSource(datasource);
	}

	public List<MedicalEquipmentPOJO> getDealerStock(int id)
	{
		List<MedicalEquipmentPOJO> searchlist=null;
		
		searchlist=getJdbcTemplate().query(
				"SELECT eq_id,eq_type,eq_price,eq_quantity  from T_XBBNHFW_DealerStock where C_id=?",
				new Object[] { id }, new TestRowMapper());	
		
	
		return searchlist;
	}
	
	
	
	public void insert(UserBean ub){
		Connection conn =ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		
		String searchQuery;
		searchQuery="Insert into T_XBBNHFW_User values(?,?,?)";
		
			try {
			//System.out.println("Creating statement");
			 stmt = conn.prepareStatement(searchQuery);
			stmt.setInt(1, ub.getU_id());		
			stmt.setString(2,ub.getU_name());
			stmt.setInt(3,ub.getType());
			stmt.execute();
			}

		catch(Exception e)
		{
			System.out.println("insert catch");
			e.printStackTrace();
		}
			finally{
				try {
					
					if(stmt != null)					
					stmt.close();				
					conn.commit();
					if(conn != null)
					conn.close();
				}			
				 catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
	}

			public void delete(UserBean ub){
				Connection conn =ConnectionManager.getConnection();
				PreparedStatement stmt = null;
				String searchQuery="delete from T_XBBNHFW_User where U_id=? ";
				try {
					stmt = conn.prepareStatement(searchQuery);
					stmt.setInt(1,ub.getU_id());
												
					stmt.execute();
										
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				finally{
					try {
						
						if(stmt != null)					
						stmt.close();				
						conn.commit();
						if(conn != null)
						conn.close();
					}			
					 catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
				}
			}
			
			
}
