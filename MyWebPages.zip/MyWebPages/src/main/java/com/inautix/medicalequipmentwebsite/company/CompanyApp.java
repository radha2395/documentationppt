package com.inautix.medicalequipmentwebsite.company;






import java.util.ArrayList;
import java.util.List;



import com.inautix.onlinemedicalequipmentwebsite.medicalequipment.*;


public class CompanyApp {
	CompanyDAO cdao=new CompanyDAO();
	public boolean callForUpdateCompany(int id,MedicalEquipmentPOJO meq,int choice,int qty,float price)
	{
		boolean res=false;
		CompanyBean cb=new CompanyBean();
		cb=cdao.getCompanyBeanGivenID(id);
		res=updateCompanyStock(cb,choice,meq,qty,price);
		return res;
	}
	
	public boolean callForAddCompany(int id,MedicalEquipmentPOJO meq)
	{
		boolean res=false;
		CompanyBean cb=new CompanyBean();
		cb=cdao.getCompanyBeanGivenID(id);
		res=addCompanyStock(cb,meq);
		return res;
	}
	

public boolean updateCompanyStock(CompanyBean cb,int choice,MedicalEquipmentPOJO medeq,int qty,float price) {
		// TODO Auto-generated method stub
	


	boolean res=false;
	MedicalEquipmentDAO meddao=new MedicalEquipmentDAO();
	
	//medeq.setEq_name(name);
	int qtty=meddao.retQty(medeq.getEq_name());
	if(choice==1)
	{
	
	//medeq.setEq_quantity(qty);
	res=meddao.addCompanyQuantity((qtty+qty), medeq, cb);
	
	}
	else if(choice==2)
	{
		
		medeq.setEq_price(price);
		res=meddao.updateCompanyPrice(price, medeq, cb);
		
	}
	
	
	
	return res;
	}
public boolean addCompanyStock(CompanyBean cb,MedicalEquipmentPOJO meq) 
{
	
	
	List<MedicalEquipmentPOJO> meqlist=new ArrayList<MedicalEquipmentPOJO>();
	MedicalEquipmentDAO medeqDao = new MedicalEquipmentDAO();
	boolean ch=false,res=false;
		res=medeqDao.insert(meq);
		meqlist.add(meq);
		ch=medeqDao.insertCompany(meq,cb);
	cb.setMeqlist(meqlist);
	if(res==true && ch==true)
	return true;
	return false;

}

public void sellMedEqByCompany(int qty,MedicalEquipmentPOJO medeq, CompanyBean cbean)
{
	MedicalEquipmentDAO meddao=new MedicalEquipmentDAO();
		int quantity=meddao.retQty(medeq.getEq_name());
	medeq.setEq_quantity(quantity);
	meddao.updateCompanyQuantity(qty,medeq,cbean);
	meddao.insertCompany(medeq,cbean);
	
}
	
}
