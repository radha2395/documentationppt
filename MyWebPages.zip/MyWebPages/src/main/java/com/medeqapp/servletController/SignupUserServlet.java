package com.medeqapp.servletController;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



import com.inautix.medicalequipmentwebsite.login.*;
import com.inautix.medicalequipmentwebsite.user.UserBean;

/**
 * Servlet implementation class SignupServlet
 */
@WebServlet("/SignupServlet")
public class SignupUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SignupUserServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)  
	        throws ServletException, IOException {  
	  
	    response.setContentType("text/html");  
	   boolean res=false;
	  
	    String id=request.getParameter("id");
	    String name=request.getParameter("name");
	    String uname=request.getParameter("username");  
	    String password=request.getParameter("userpass"); 
	    String confirmpwd=request.getParameter("confirmpass");
	    
	    
	    LoginDetailsDAO ldao=new LoginDetailsDAO();
	
		UserBean ub=new UserBean();
		 ub.setType(3);
		 ub.setU_id(Integer.parseInt(id));
		ub.setU_name(name);
	res=ldao.signUp(3, uname, password,confirmpwd, null, null,ub);
		if(res==true)
	 	 {
	 		RequestDispatcher rd=request.getRequestDispatcher("index.html");  
	        rd.forward(request, response);  
	} 
	
	}
	   /* ServletConfig config=getServletConfig();
	    //read from servlet config
	    String validPass = config.getInitParameter("password");
	    System.out.println("validPass : "+ validPass);*/
	    
	   /* // read from servlet context    
	    ServletContext context=getServletContext();  
	    String  connectURL = context.getInitParameter("connection-url");
	    System.out.println("connectURL :"+ connectURL);
	    //set attribute
	    context.setAttribute("companyName", "iNautix");
	    System.out.println("CompanyName :"+context.getAttribute("companyName"*///));
	    
	  
	   
}
