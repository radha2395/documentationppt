package com.medeqapp.servletController;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.inautix.medicalequipmentwebsite.company.CompanyBean;
import com.inautix.onlinemedicalequipmentwebsite.dealer.DealerApp;
import com.inautix.onlinemedicalequipmentwebsite.medicalequipment.MedicalEquipmentPOJO;

/**
 * Servlet implementation class DealerBuyServlet
 */
@WebServlet("/DealerBuyServlet")
public class DealerBuyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DealerBuyServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");  
		DealerApp dapp=new DealerApp();
	   HttpSession session=request.getSession(true);
	    String choice=request.getParameter("radio");
	  
	    if(choice.equals("Company"))
	    {
	    	List<MedicalEquipmentPOJO> productlist=null;
	    	String str=request.getParameter("company");
	    	session.setAttribute("companyname",str);
	    	productlist=dapp.searchByCompany(str);
	    	if(productlist!=null)
	    	{
	    	session.setAttribute("productlist", productlist);
	    	RequestDispatcher rd=request.getRequestDispatcher("SearchByCompanyResultsForBuy.jsp");
	    	rd.forward(request, response);
	    }
	    	else
	    		{
	    		PrintWriter out=response.getWriter();
	    		out.write("<h3>No Results Found </h3>");
	    		RequestDispatcher rd=request.getRequestDispatcher("SearchByDealerFirstForBuy.jsp");
		    	rd.include(request, response);}
	    	
}
	    else if(choice.equals("Product"))
	    {
	    	List<CompanyBean> companylist=null;
	    	String str=request.getParameter("product");
	    	session.setAttribute("productname",str);
	    	companylist=dapp.searchByProducts(str);
	    	if(companylist!=null)
	    	{	session.setAttribute("companylist", companylist);
	    	RequestDispatcher rd=request.getRequestDispatcher("SearchByProductResultsForBuy.jsp");
	    	rd.forward(request, response);
	    	
	    }
	    	else
    		{
    		PrintWriter out=response.getWriter();
    		out.write("<h3>No Results Found </h3>");
    		RequestDispatcher rd=request.getRequestDispatcher("SearchAndBuyByDealerFirst.jsp");
	    	rd.include(request, response);}
    		
	    }
	    

}


}
