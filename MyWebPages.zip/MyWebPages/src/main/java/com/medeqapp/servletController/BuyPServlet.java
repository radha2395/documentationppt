package com.medeqapp.servletController;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.inautix.medicalequipmentwebsite.company.CompanyBean;
import com.inautix.medicalequipmentwebsite.company.CompanyDAO;
import com.inautix.onlinemedicalequipmentwebsite.dealer.*;
import com.inautix.onlinemedicalequipmentwebsite.medicalequipment.MedicalEquipmentPOJO;

/**
 * Servlet implementation class BuyPServlet
 */
@WebServlet("/BuyPServlet")
public class BuyPServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BuyPServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session=request.getSession(true);
		//List<MedicalEquipmentPOJO> cprodlist=null;
       	DealerApp dapp=new DealerApp();
      	 String cname=(String)session.getAttribute("companyname");
     	 CompanyDAO cdao=new CompanyDAO();
     	 
     	 String pname=request.getParameter("product");
     	 session.setAttribute("productname", pname);
     	 CompanyBean cb=cdao.getCompanyBean(cname);
     	List<MedicalEquipmentPOJO> plist=(List<MedicalEquipmentPOJO>)session.getAttribute("productlist");
     	MedicalEquipmentPOJO medeq=new MedicalEquipmentPOJO();
     	Iterator<MedicalEquipmentPOJO> itr=plist.iterator();
     	while(itr.hasNext())
     	{
     		MedicalEquipmentPOJO meq=itr.next();
          	System.out.println(meq.getEq_id());
     	 if( meq.getEq_name().equals(pname))
     		 {
     		 medeq.setEq_id(meq.getEq_id());
     		 medeq.setEq_name(meq.getEq_name());
     		 medeq.setEq_price(meq.getEq_price());
     		 break;
     		 }
     	}
     	System.out.println(medeq.getEq_id());
		String quantity=request.getParameter("qty");
		 medeq.setEq_quantity(Integer.parseInt(quantity));
		/*cprodlist.add(medeq);
		cb.setMeqlist(cprodlist);*/
		boolean res=dapp.buyMedEqByDealer(medeq,cb);
		 if(res==true){
			 RequestDispatcher rd=request.getRequestDispatcher("WelcomeDealer.jsp");
			 rd.forward(request, response);
		 }
		/* else
		 {
			 RequestDispatcher rd=request.getRequestDispatcher("BuyP.jsp");
			 rd.include(request, response);
		 }*/
	}

}
