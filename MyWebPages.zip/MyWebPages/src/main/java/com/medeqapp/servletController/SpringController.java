package com.medeqapp.servletController;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.inautix.medicalequipmentwebsite.company.CompanyBean;
import com.inautix.medicalequipmentwebsite.company.CompanyDAO;
import com.inautix.medicalequipmentwebsite.user.UserApp;
import com.inautix.medicalequipmentwebsite.user.UserDAO;
import com.inautix.onlinemedicalequipmentwebsite.dealer.DealerDAO;
import com.inautix.onlinemedicalequipmentwebsite.medicalequipment.MedicalEquipmentPOJO;



@RestController
@RequestMapping(value = "/user")
public class SpringController 
{
	
	@Autowired
	UserDAO udao;
		
	 @RequestMapping(value = "/searchbycompany/{company}/{inputName}" , method = RequestMethod.GET )
	  public List<MedicalEquipmentPOJO> getSearchResultsforCompany(@PathVariable("company") String company,@PathVariable("inputName") String inputName) {
		 System.out.println("In controller--->>"+company+" "+inputName);
		
		 List<MedicalEquipmentPOJO> plist,productlist;
		 productlist=new ArrayList<MedicalEquipmentPOJO>();
		 DealerDAO ddao=new DealerDAO();
		 int did=ddao.retDId(inputName);
		 List<Integer> eqid=ddao.getEQidforDid(did);
		 CompanyDAO cdao=new CompanyDAO();
			
			
	       
	        int id5=cdao.retId(company);
	        System.out.println(id5);
	        plist =udao.getDealerStock(id5);
	    	//plist=uapp.searchByCompany(company);
	    	int id;
	    
		Iterator<MedicalEquipmentPOJO> itr=plist.iterator();
		Iterator<Integer> itr1=eqid.iterator();
		while(itr1.hasNext())
		{
			 id=itr1.next();
		while(itr.hasNext())
		{
			MedicalEquipmentPOJO mb=(MedicalEquipmentPOJO)itr.next();
		if(mb.getEq_id()==id)
				{
				productlist.add(mb);
				break;
				}
			}
		}
   	return productlist;
     }	
 
		 
	 @RequestMapping(value = "/searchbyproduct/{product}/{inputName}" , method = RequestMethod.GET )
	  public List<CompanyBean> getSearchResultsforProduct(@PathVariable("product") String product,@PathVariable("inputName") String inputName) {
		 System.out.println("In controller--->>"+product+" "+inputName);
		 UserApp uapp=new UserApp();
		 DealerDAO ddao=new DealerDAO();
		 int did=ddao.retDId(inputName);
		 List<CompanyBean> companylist=new ArrayList<CompanyBean>();
		 List<Integer> eqid=ddao.getEQidforDid(did);
		 List<CompanyBean>	clist = null;
		 Iterator<Integer> itr1=eqid.iterator();
		 while(itr1.hasNext())
		 {int id=itr1.next();
		 int cid=ddao.getCidforEquid(id);
		
	    	
		clist=uapp.searchByProducts(product);
		 Iterator<CompanyBean> itr=clist.iterator();
			while(itr.hasNext())
			{
				CompanyBean cb=(CompanyBean)itr.next();
				if(cb.getC_id()==cid)
				{
					companylist.add(cb);
					break;
				}
			}
		 }
	return companylist;
    }	
}
