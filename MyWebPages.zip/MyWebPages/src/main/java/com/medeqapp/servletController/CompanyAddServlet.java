package com.medeqapp.servletController;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.inautix.medicalequipmentwebsite.company.CompanyApp;
import com.inautix.medicalequipmentwebsite.login.*;
import com.inautix.onlinemedicalequipmentwebsite.medicalequipment.MedicalEquipmentPOJO;

/**
 * Servlet implementation class CompanyAddServlet
 */
@WebServlet("/CompanyAddServlet")
public class CompanyAddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CompanyAddServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 response.setContentType("text/html");  
		 HttpSession session = request.getSession(true);
		    String id=request.getParameter("m_id");
		    String name=request.getParameter("name");
		    String price=request.getParameter("price");  
		    String qty=request.getParameter("qty"); 
		    boolean res=false;
		    int id1;
		    CompanyApp ca=new CompanyApp();
		    MedicalEquipmentPOJO meq=new MedicalEquipmentPOJO();
		    
		    meq.setEq_id(Integer.parseInt(id));
		    meq.setEq_name(name);
		    meq.setEq_price(Float.parseFloat(price));
		    meq.setEq_quantity(Integer.parseInt(qty));
		    String uname=(String) session.getAttribute("username");
		    String pwd=(String) session.getAttribute("password");
		    LoginDetailsDAO ldao=new LoginDetailsDAO();
		    LoginDetailsBean ldb=new LoginDetailsBean();
		    ldb.setUsername(uname);
		    ldb.setPwd(pwd);
		    ldb.setType(1);
		   id1= ldao.retId(ldb);
		   res=ca.callForAddCompany(id1, meq);
		   if(res==true)
		   {
			   RequestDispatcher rd=request.getRequestDispatcher("welcomecompany.jsp");  
		        rd.forward(request, response);  
		   }
	}

}
