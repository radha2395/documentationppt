package com.medeqapp.servletController;

import java.io.IOException;




import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.inautix.medicalequipmentwebsite.company.*;
import com.inautix.medicalequipmentwebsite.login.*;

/**
 * Servlet implementation class SignupServlet
 */

public class SignupCompanyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SignupCompanyServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)  
	        throws ServletException, IOException {  
	  
	    response.setContentType("text/html");  
	    
	    String id=request.getParameter("id");
	    String name=request.getParameter("name");
	    String uname=request.getParameter("username");  
	    String password=request.getParameter("userpass"); 
	    String confirmpwd=request.getParameter("confirmpass");
	    boolean res=false;
	    
	    LoginDetailsDAO ldao=new LoginDetailsDAO();
	 
		  CompanyBean cb=new CompanyBean();
		  cb.setC_id(Integer.parseInt(id));
			cb.setC_name(name);
			cb.setType(1);
			
	 	res=ldao.signUp(1, uname, password,confirmpwd, cb, null, null);
	 	if(res==true)
	 	 {
	 		RequestDispatcher rd=request.getRequestDispatcher("index.html");  
	        rd.forward(request, response);  
	}
	}
	  
	   
}
