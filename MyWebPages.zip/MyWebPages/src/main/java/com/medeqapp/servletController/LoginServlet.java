package com.medeqapp.servletController;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.inautix.medicalequipmentwebsite.login.LoginDetailsBean;
import com.inautix.medicalequipmentwebsite.login.LoginDetailsDAO;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/Login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public LoginServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */

	public void doPost(HttpServletRequest request, HttpServletResponse response)  
	        throws ServletException, IOException {  
	  
	    response.setContentType("text/html");  
	    PrintWriter out = response.getWriter();  
	   
	   boolean res=false;
	    String username=request.getParameter("username");  
	    String password=request.getParameter("userpass"); 
	    String choice=request.getParameter("radio");
	   
	    if(choice.equals("Company"))
	 	  {
	    	LoginDetailsDAO ldao=new LoginDetailsDAO();
	    	 LoginDetailsBean lb=new LoginDetailsBean();
	    	 	    
	 	    res=ldao.login(1, username, password);
	 	    if(res==true)
	 	    {
	 	    	 HttpSession session = request.getSession(true);
	 	    	 session.setAttribute("username",username);
				    session.setAttribute("password", password);
				    lb.setUsername(username);
			        lb.setPwd(password);
			        lb.setType(1);
	 		    RequestDispatcher rd=request.getRequestDispatcher("welcomecompany.jsp");  
		        rd.forward(request, response); 
		       
		        int id=ldao.retId(lb);
		        session.setAttribute("id", id);
		    }
	 	   else
		    {
		    	out.println("<html><b><div style=width:650px;margin-top: 80px;line-height: 1.6em;text-align: center;>Invalid UserName or Password</div></b><html>");
		    	RequestDispatcher rd=request.getRequestDispatcher("index.jsp");  
		        rd.include(request, response);  
		    }
	 	  }
	 else if(choice.equals("Dealer"))
	 {
		
		 LoginDetailsDAO ldao=new LoginDetailsDAO();
		 LoginDetailsBean lb=new LoginDetailsBean();  
		    res=ldao.login(2, username, password);
		    if(res==true)
	 	    {
	 	    	 HttpSession session = request.getSession(true);
	 	    
		        session.setAttribute("username",username);
			    session.setAttribute("password", password);
		        
	 		    RequestDispatcher rd=request.getRequestDispatcher("WelcomeDealer.jsp");  
		        rd.forward(request, response); 
		        lb.setUsername(username);
		        lb.setPwd(password);
		        lb.setType(2);
		        int id=ldao.retId(lb);
		    	session.setAttribute("id", id);
	 	    }
	 	   else
		    {
		    	out.println("<html><b><div style=width:650px;margin-top: 80px;line-height: 1.6em;text-align: center;>Invalid UserName or Password</div></b><html>");
		    	RequestDispatcher rd=request.getRequestDispatcher("index.jsp");  
		        rd.include(request, response);  
		    }
	 }
	 else if(choice.equals("User"))
	 {
		
		 LoginDetailsDAO ldao=new LoginDetailsDAO();
		 LoginDetailsBean lb=new LoginDetailsBean();    
		    res=ldao.login(3, username, password);
		    if(res==true)
	 	    {
	 	    	 HttpSession session = request.getSession(true);
	 	    
		        session.setAttribute("username",username);
			    session.setAttribute("password", password);
		        
	 		    RequestDispatcher rd=request.getRequestDispatcher("welcomeUser.jsp");  
		        rd.forward(request, response); 
		        lb.setUsername(username);
		        lb.setPwd(password);
		        lb.setType(3);
		        int id=ldao.retId(lb);
		    	session.setAttribute("id", id);
	 	    }
	 	   else
		    {
		    	out.println("<html><b><div style=width:650px;margin-top: 80px;line-height: 1.6em;text-align: center;>Invalid UserName or Password</div></b><html>");
		    	RequestDispatcher rd=request.getRequestDispatcher("index.jsp");  
		        rd.include(request, response);  
		    }
	 }
}  
}
