package com.medeqapp.servletController;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.inautix.medicalequipmentwebsite.company.*;
import com.inautix.onlinemedicalequipmentwebsite.dealer.*;
import com.inautix.onlinemedicalequipmentwebsite.medicalequipment.*;

/**
 * Servlet implementation class BuyCServlet
 */
@WebServlet("/BuyCServlet")
public class BuyCServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BuyCServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 CompanyBean cbean=new CompanyBean(); 
		 HttpSession session=request.getSession(true);
		 String str1=request.getParameter("company");
		 session.setAttribute("productname", str1);
		 String pname=(String)session.getAttribute("productname");
		 List<CompanyBean> companylist=(List<CompanyBean>)session.getAttribute("companylist");
		 Iterator<CompanyBean> itr=companylist.iterator();
		        while(itr.hasNext())
		        {
		       CompanyBean cb=itr.next();
		       cbean=new CompanyBean();
		       String str2=cb.getC_name();
		         if(str2.equals(str1))
		         {
		        	 cbean.setC_id(cb.getC_id());
		        	 cbean.setC_name(cb.getC_name());
		        	 cbean.setType(cb.getType());
		         }
		          }
		        MedicalEquipmentPOJO meq,medeq;
		        medeq=new MedicalEquipmentPOJO();
		        List<MedicalEquipmentPOJO> productlist=cbean.getMeqlist();
		        Iterator<MedicalEquipmentPOJO> itr1=productlist.iterator();
		        while(itr1.hasNext())
		        {
		        meq=itr1.next();
		        medeq=new MedicalEquipmentPOJO();
		        str1=meq.getEq_name();
		         if(str1.equals(pname))
		         {
		        	 medeq.setEq_id(meq.getEq_id());
		     		 medeq.setEq_name(meq.getEq_name());
		     		 medeq.setEq_price(meq.getEq_price());
		     		 break;
		         }
		         }
		      
		     	
		     	DealerDAO ddao=new DealerDAO();
		     	CompanyDAO cdao=new CompanyDAO();
		     	DealerApp dapp=new DealerApp();
			String qty=request.getParameter("qty");
				 medeq.setEq_quantity(Integer.parseInt(qty));
				               int id=cdao.retId(str1);
		        ddao.insertStock(medeq, id);
		       boolean res=dapp.buyMedEqByDealer(medeq,cbean);
		       if(res==true)
				 {
					 RequestDispatcher rd=request.getRequestDispatcher("WelcomeDealer.jsp");
					 rd.forward(request, response);
				 }
	}

}
