package com.medeqapp.servletController;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.inautix.medicalequipmentwebsite.company.CompanyApp;

import com.inautix.onlinemedicalequipmentwebsite.medicalequipment.MedicalEquipmentPOJO;

/**
 * Servlet implementation class CompanyUpdateQuantity
 */
@WebServlet("/CompanyUpdateQuantity")
public class CompanyUpdateQuantity extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CompanyUpdateQuantity() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
// TODO Auto-generated method stub
		HttpSession session=request.getSession(true);
		 String name=request.getParameter("name");
		    boolean res=false;
		   
		    MedicalEquipmentPOJO medeq=new MedicalEquipmentPOJO();
			medeq.setEq_name(name);
			CompanyApp ca=new CompanyApp();
		    String qty=request.getParameter("qty");
		    int id=(Integer)session.getAttribute("id");
	    	res=ca.callForUpdateCompany(id, medeq, 1, Integer.parseInt(qty), 0);
	    	if(res==true)
			   {
				   RequestDispatcher rd=request.getRequestDispatcher("welcomecompany.jsp");  
			        rd.forward(request, response);  
			   }
	}

}
