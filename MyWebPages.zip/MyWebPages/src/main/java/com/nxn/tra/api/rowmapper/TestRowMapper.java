package com.nxn.tra.api.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import com.inautix.onlinemedicalequipmentwebsite.medicalequipment.MedicalEquipmentPOJO;


public class TestRowMapper implements RowMapper<MedicalEquipmentPOJO> {

	public MedicalEquipmentPOJO mapRow(ResultSet rs, int rownum) throws SQLException {
		// TODO Auto-generated method stub
		
		MedicalEquipmentPOJO mb=new MedicalEquipmentPOJO();
		mb.setEq_id(rs.getInt(1));
		mb.setEq_name(rs.getString(2));
		mb.setEq_price(rs.getFloat(3));
		mb.setEq_quantity(rs.getInt(4));
		return mb;
	}

}
