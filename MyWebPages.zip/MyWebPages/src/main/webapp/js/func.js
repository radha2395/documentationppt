/**
 * 
 */

/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */



function validate(){
	
	if(document.getElementById("username").value==""){
		alert("Enter values!");
	}
	if(document.getElementById("pwd").value==""){
		alert("Enter values!");
	}
}
function showCompany()
{
	document.getElementById("company").hidden=false;
	
	}
function showProduct()
{
	document.getElementById("product").hidden=false;
	
	}
function validatesignup(){
	if(document.getElementById("name").value==""){
		alert("Enter values!");
	}
	if(document.getElementById("id").value==""){
		alert("Enter values!");
	}
	if(document.getElementById("username").value==""){
		alert("Enter values!");
	}
	if(document.getElementById("pwd").value==""){
		alert("Enter values!");
	}
	if(document.getElementById("pwd1").value==""){
		alert("Enter values!");
	}
}
