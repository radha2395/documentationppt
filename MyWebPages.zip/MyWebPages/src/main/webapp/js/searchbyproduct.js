angular.module('vishalsrini',[])
  .controller('gitUsers',function($scope,$http){
  $http.get("/user/searchbyproduct"+product+"/"+inputName+"\"").then(function(response){
    $scope.datas = response.data;
  })
})