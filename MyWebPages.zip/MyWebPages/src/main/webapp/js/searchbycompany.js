angular.module('vishalsrini',[])
  .controller('gitUsers',function($scope,$http){
  $http.get("/user/searchbycompany"+company+"/"+inputName+"\"").then(function(response){
    $scope.datas = response.data;
  })
})