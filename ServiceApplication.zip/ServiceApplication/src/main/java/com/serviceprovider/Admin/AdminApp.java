package com.serviceprovider.Admin;

public class AdminApp {

	public void fixAppointment(int customer_id, int serviceprovider_id,int servicetype,String time) {
		
		  AdminDAO adao=new AdminDAO();
		  
	}

}
