create table service(service_id number,service_name varchar(20));
insert into service values(1,'Electrical');
insert into service values(2,'Plumbing');
insert into service values(3,'Carpentry');
insert into service values(4,'Mechanic');
insert into service values(5,'Technical assistance');
insert into service values(6,'House Cleaning');
select * from service;

