create table t_xbbnhfn_servicetypedetails(sp_id number,service_type number);
