angular.module('customerApp',[]).controller('customerCtrl',function($scope) {
	
	$scope.showTypes=false;
	$scope.showDetails=false;
	$scope.showSearch=function(){
		$scope.showTypes=!$scope.showTypes;};
		$scope.showSpDet=function(){
			$scope.showDetails=!$scope.showDetails;
		};
		$scope.custChoice=function(){
			$scope.index=this.$index;
			$scope.id=$scope.spdata[$scope.index].serviceproviderid;
		};
		$scope.getCustDetails=function($scope,$http){
			$http.get("172.24.18.77:8080/service/CustomerDetails").then(function(response){
			    $scope.customerdata = response.data;
		});};

		$scope.getSpDetails=function($scope,$http){
			$http.get("172.24.18.77:8080/service/SPdetails").then(function(response){
			    $scope.spdata = response.data;
		});};
		/*$scope.reqAppointmentDetails=function($scope,$http){
	    $http.get("172.24.18.77:8080/service/Appointmentdetails").then(function(response){
		    $scope.appointmentdata = response.data;
	});};*/
		    });